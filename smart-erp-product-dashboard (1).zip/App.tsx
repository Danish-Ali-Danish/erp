import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import ProductsPage from './components/ProductsPage';
import CustomerPage from './components/CustomerPage';
import SalesPage from './components/SalesPage';
import HRPage from './components/HRPage';
import ReportsPage from './components/ReportsPage';
import SettingsPage from './components/SettingsPage';
import ActivityPage from './components/ActivityPage';
import { initialProducts, initialCustomers, initialSales, initialEmployees, initialActivityLog, Product, Customer, Sale, Employee, ActivityLog, ActivityType, StockStatus, SaleStatus } from './types';

export type Page = 'Dashboard' | 'Products' | 'Customers' | 'Sales' | 'HR' | 'Reports' | 'Activity' | 'Settings';
export type Theme = 'light' | 'dark';

const App: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activePage, setActivePage] = useState<Page>('Dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [theme, setTheme] = useState<Theme>(() => {
      if (typeof window !== 'undefined' && localStorage.getItem('theme')) {
          return localStorage.getItem('theme') as Theme;
      }
      if (typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches) {
          return 'dark';
      }
      return 'light';
  });

  // Centralized State
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [sales, setSales] = useState<Sale[]>(initialSales);
  const [employees, setEmployees] = useState<Employee[]>(initialEmployees);
  const [activityLog, setActivityLog] = useState<ActivityLog[]>(initialActivityLog);
  
  const logActivity = (type: ActivityType, details: string) => {
    const newLog: ActivityLog = {
      id: `LOG${Date.now()}`,
      type,
      details,
      user: 'Admin User',
      timestamp: new Date().toISOString(),
    };
    setActivityLog(prev => [newLog, ...prev]);
  };

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const handlePageChange = (page: Page) => {
    setActivePage(page);
    setSearchTerm(''); // Reset search when changing pages
  };

  // CRUD Handlers
  const handleAddProduct = (newProduct: Omit<Product, 'id' | 'status' | 'createdAt'>) => {
      const productToAdd: Product = {
          ...newProduct,
          id: `PROD${Date.now()}`,
          status: newProduct.stock > 50 ? StockStatus.InStock : newProduct.stock > 0 ? StockStatus.LowStock : StockStatus.OutOfStock,
          createdAt: new Date().toISOString().split('T')[0],
      };
      setProducts(prev => [productToAdd, ...prev]);
      logActivity(ActivityType.ProductCreated, `Created product: "${productToAdd.name}"`);
  };
  const handleUpdateProduct = (updatedProduct: Product) => {
      const newStatus = updatedProduct.stock > 50 ? StockStatus.InStock : updatedProduct.stock > 0 ? StockStatus.LowStock : StockStatus.OutOfStock;
      setProducts(products.map(p => p.id === updatedProduct.id ? { ...updatedProduct, status: newStatus } : p));
      logActivity(ActivityType.ProductUpdated, `Updated product: "${updatedProduct.name}"`);
  };
  const handleDeleteProduct = (product: Product) => {
    setProducts(products.filter(p => p.id !== product.id));
    logActivity(ActivityType.ProductDeleted, `Deleted product: "${product.name}"`);
  };

  const handleAddCustomer = (newCustomerData: Omit<Customer, 'id' | 'totalSpent' | 'joinedAt'>) => {
      const newCustomer: Customer = { ...newCustomerData, id: `CUST${Date.now()}`, totalSpent: 0, joinedAt: new Date().toISOString().split('T')[0] };
      setCustomers(prev => [newCustomer, ...prev]);
      logActivity(ActivityType.CustomerCreated, `Created customer: "${newCustomer.name}"`);
  };
  const handleUpdateCustomer = (updatedCustomer: Customer) => {
    setCustomers(customers.map(c => c.id === updatedCustomer.id ? updatedCustomer : c));
    logActivity(ActivityType.CustomerUpdated, `Updated customer: "${updatedCustomer.name}"`);
  };
  const handleDeleteCustomer = (customer: Customer) => {
    setCustomers(customers.filter(c => c.id !== customer.id));
    logActivity(ActivityType.CustomerDeleted, `Deleted customer: "${customer.name}"`);
  };
  
  const handleAddEmployee = (newEmployeeData: Omit<Employee, 'id' | 'startDate'>) => {
      const newEmployee: Employee = { ...newEmployeeData, id: `EMP${Date.now()}`, startDate: new Date().toISOString().split('T')[0] };
      setEmployees(prev => [newEmployee, ...prev]);
      logActivity(ActivityType.EmployeeCreated, `Added employee: "${newEmployee.name}"`);
  };
  const handleUpdateEmployee = (updatedEmployee: Employee) => {
    setEmployees(employees.map(e => e.id === updatedEmployee.id ? updatedEmployee : e));
    logActivity(ActivityType.EmployeeUpdated, `Updated employee: "${updatedEmployee.name}"`);
  };
  const handleDeleteEmployee = (employee: Employee) => {
    setEmployees(employees.filter(e => e.id !== employee.id));
    logActivity(ActivityType.EmployeeDeleted, `Deleted employee: "${employee.name}"`);
  };

  const handleAddSale = (newSaleData: Omit<Sale, 'id' | 'date'>) => {
        const newSale: Sale = {
            ...newSaleData,
            id: `SALE${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
        };
        setSales(prev => [newSale, ...prev]);
        logActivity(ActivityType.SaleCreated, `Created invoice #${newSale.id} for ${newSale.customerName}`);
        
        // Update customer's total spent if sale is paid
        const customer = customers.find(c => c.name === newSale.customerName);
        if (customer && newSale.status === SaleStatus.Paid) {
            const updatedCustomer = { ...customer, totalSpent: customer.totalSpent + newSale.amount };
            handleUpdateCustomer(updatedCustomer);
        }

        // Update product stock levels
        newSale.products.forEach(item => {
            const product = products.find(p => p.id === item.productId);
            if(product) {
                const updatedProduct = { ...product, stock: product.stock - item.quantity };
                handleUpdateProduct(updatedProduct);
            }
        });
    };

  const handleResetData = () => {
    if (window.confirm('Are you sure you want to reset all application data? This action cannot be undone.')) {
        setProducts(initialProducts);
        setCustomers(initialCustomers);
        setSales(initialSales);
        setEmployees(initialEmployees);
        setActivityLog(initialActivityLog);
        logActivity(ActivityType.SystemReset, "Application data has been reset");
        alert('Application data has been reset to its initial state.');
        setActivePage('Dashboard');
    }
  };

  const renderPage = () => {
    const pageProps = { searchTerm, onSearch: setSearchTerm };
    switch (activePage) {
      case 'Dashboard':
        return <Dashboard products={products} sales={sales} customers={customers} />;
      case 'Products':
        return <ProductsPage products={products} onAddProduct={handleAddProduct} onUpdateProduct={handleUpdateProduct} onDeleteProduct={handleDeleteProduct} {...pageProps} />;
      case 'Customers':
        return <CustomerPage customers={customers} onAddCustomer={handleAddCustomer} onUpdateCustomer={handleUpdateCustomer} onDeleteCustomer={handleDeleteCustomer} {...pageProps} />;
      case 'Sales':
        return <SalesPage sales={sales} products={products} customers={customers} onAddSale={handleAddSale} {...pageProps} />;
      case 'HR':
        return <HRPage employees={employees} onAddEmployee={handleAddEmployee} onUpdateEmployee={handleUpdateEmployee} onDeleteEmployee={handleDeleteEmployee} {...pageProps} />;
      case 'Reports':
        return <ReportsPage sales={sales} products={products} customers={customers} />;
      case 'Activity':
        return <ActivityPage activityLog={activityLog} {...pageProps} />;
      case 'Settings':
        return <SettingsPage onResetData={handleResetData} />;
      default:
        return <Dashboard products={products} sales={sales} customers={customers} />;
    }
  };

  return (
    <div className="flex h-screen bg-background dark:bg-dark-background">
      <Sidebar 
        sidebarOpen={sidebarOpen} 
        setSidebarOpen={setSidebarOpen} 
        activePage={activePage}
        setActivePage={handlePageChange}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
            setSidebarOpen={setSidebarOpen} 
            activePage={activePage} 
            theme={theme}
            toggleTheme={toggleTheme}
            searchTerm={searchTerm}
            onSearch={setSearchTerm}
        />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background dark:bg-dark-background">
          <div className="container mx-auto px-6 py-8">
            {renderPage()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;