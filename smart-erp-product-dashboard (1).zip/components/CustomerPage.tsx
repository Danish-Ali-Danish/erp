import React, { useState, useMemo } from 'react';
import { Customer } from '../types';
import { ChevronUpIcon, ChevronDownIcon, PencilIcon, TrashIcon, ExportIcon } from './icons';
import AddCustomerModal from './AddCustomerModal';
import EditCustomerModal from './EditCustomerModal';
import Pagination from './Pagination';

type SortKey = keyof Customer;

interface CustomerTableProps {
    customers: Customer[];
    onEdit: (customer: Customer) => void;
    onDelete: (customer: Customer) => void;
}

const CustomerTable: React.FC<CustomerTableProps> = ({ customers, onEdit, onDelete }) => {
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'ascending' | 'descending' } | null>({ key: 'joinedAt', direction: 'descending' });

    const sortedCustomers = useMemo(() => {
        let sortableItems = [...customers];
        if (sortConfig !== null) {
        sortableItems.sort((a, b) => {
            if (a[sortConfig.key] < b[sortConfig.key]) {
            return sortConfig.direction === 'ascending' ? -1 : 1;
            }
            if (a[sortConfig.key] > b[sortConfig.key]) {
            return sortConfig.direction === 'ascending' ? 1 : -1;
            }
            return 0;
        });
        }
        return sortableItems;
    }, [customers, sortConfig]);

    const requestSort = (key: SortKey) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (key: SortKey) => {
        if (!sortConfig || sortConfig.key !== key) {
            return <ChevronUpIcon className="w-4 h-4 text-gray-400 invisible group-hover:visible" />;
        }
        return sortConfig.direction === 'ascending' ? <ChevronUpIcon className="w-4 h-4" /> : <ChevronDownIcon className="w-4 h-4" />;
    };
    
    const headers: { key: SortKey, label: string }[] = [
        { key: 'name', label: 'Name' },
        { key: 'email', label: 'Email' },
        { key: 'phone', label: 'Phone' },
        { key: 'totalSpent', label: 'Total Spent' },
        { key: 'joinedAt', label: 'Date Joined' },
    ];

    return (
        <div className="bg-card-bg dark:bg-dark-card-bg shadow-md rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead className="bg-gray-50 dark:bg-gray-800">
                        <tr>
                            {headers.map((header) => (
                                <th key={header.key} scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">
                                <button onClick={() => requestSort(header.key)} className="group flex items-center space-x-1">
                                    <span>{header.label}</span>
                                    {getSortIcon(header.key)}
                                </button>
                                </th>
                            ))}
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200 dark:bg-dark-card-bg dark:divide-gray-700">
                        {sortedCustomers.map((customer) => (
                        <tr key={customer.id} className="hover:bg-gray-50 dark:hover-bg-gray-700/50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-text-primary dark:text-dark-text-primary">{customer.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{customer.email}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{customer.phone}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">${customer.totalSpent.toFixed(2)}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{customer.joinedAt}</td>
                             <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div className="flex items-center space-x-2">
                                    <button onClick={() => onEdit(customer)} className="text-primary-600 hover:text-primary-900 dark:text-primary-400 dark:hover:text-primary-200 transition duration-150 ease-in-out">
                                        <PencilIcon className="w-5 h-5"/>
                                    </button>
                                    <button onClick={() => onDelete(customer)} className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-200 transition duration-150 ease-in-out">
                                        <TrashIcon className="w-5 h-5"/>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        ))}
                    </tbody>
                </table>
            </div>
             {customers.length === 0 && (
                <div className="text-center py-10 text-text-secondary dark:text-dark-text-secondary">
                    No customers found.
                </div>
            )}
        </div>
    );
};

interface CustomerPageProps {
    customers: Customer[];
    onAddCustomer: (newCustomer: Omit<Customer, 'id' | 'totalSpent' | 'joinedAt'>) => void;
    onUpdateCustomer: (updatedCustomer: Customer) => void;
    onDeleteCustomer: (customer: Customer) => void;
    searchTerm: string;
}

const ITEMS_PER_PAGE = 10;

const CustomerPage: React.FC<CustomerPageProps> = ({ customers, onAddCustomer, onUpdateCustomer, onDeleteCustomer, searchTerm }) => {
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const filteredCustomers = useMemo(() => {
        return customers.filter(c =>
            c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            c.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            c.phone.includes(searchTerm)
        );
    }, [customers, searchTerm]);

    const totalPages = Math.ceil(filteredCustomers.length / ITEMS_PER_PAGE);
    const paginatedCustomers = filteredCustomers.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            setCurrentPage(page);
        }
    };
    
    const handleUpdate = (updatedCustomer: Customer) => {
        onUpdateCustomer(updatedCustomer);
        setEditingCustomer(null);
    };

    const handleDelete = (customer: Customer) => {
        if(window.confirm(`Are you sure you want to delete ${customer.name}?`)){
            onDeleteCustomer(customer)
        }
    }

    const handleExport = () => {
        const csvHeaders = ["ID", "Name", "Email", "Phone", "Total Spent", "Date Joined"];
        const rows = filteredCustomers.map(c => [
            c.id,
            `"${c.name.replace(/"/g, '""')}"`,
            c.email,
            c.phone,
            c.totalSpent,
            c.joinedAt
        ].join(','));

        const csvContent = "data:text/csv;charset=utf-8," + [csvHeaders.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "customers.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-semibold text-text-primary dark:text-dark-text-primary sr-only">Customers</h2>
                 <div className="flex items-center gap-2">
                    <button
                        onClick={handleExport}
                        className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-md hover:bg-gray-700 dark:bg-gray-500 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-150"
                    >
                        <ExportIcon className="w-4 h-4" />
                        Export
                    </button>
                    <button
                        onClick={() => setIsAddModalOpen(true)}
                        className="px-5 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition duration-150"
                    >
                        Add Customer
                    </button>
                </div>
            </div>
            <CustomerTable 
                customers={paginatedCustomers}
                onEdit={setEditingCustomer}
                onDelete={handleDelete}
            />
            <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
            />
            {isAddModalOpen && (
                <AddCustomerModal 
                    onClose={() => setIsAddModalOpen(false)}
                    onAddCustomer={onAddCustomer}
                />
            )}
            {editingCustomer && (
                <EditCustomerModal
                    customer={editingCustomer}
                    onClose={() => setEditingCustomer(null)}
                    onUpdateCustomer={handleUpdate}
                />
            )}
        </div>
    );
}

export default CustomerPage;