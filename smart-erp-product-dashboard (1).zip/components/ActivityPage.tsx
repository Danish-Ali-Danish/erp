import React, { useState, useMemo } from 'react';
import { ActivityLog, ActivityType } from '../types';
import { ProductsIcon, CustomersIcon, SalesIcon, UsersIcon, SettingsIcon, PencilIcon, TrashIcon } from './icons';
import Pagination from './Pagination';

interface ActivityPageProps {
    activityLog: ActivityLog[];
    searchTerm: string;
}

const ITEMS_PER_PAGE = 15;

const getActivityIcon = (type: ActivityType) => {
    const className = "w-5 h-5";
    if (type.includes('Product')) return <ProductsIcon className={`${className} text-blue-500`} />;
    if (type.includes('Customer')) return <CustomersIcon className={`${className} text-green-500`} />;
    if (type.includes('Sale')) return <SalesIcon className={`${className} text-purple-500`} />;
    if (type.includes('Employee')) return <UsersIcon className={`${className} text-orange-500`} />;
    if (type.includes('Reset')) return <TrashIcon className={`${className} text-red-500`} />;
    return <SettingsIcon className={`${className} text-gray-500`} />;
};

const formatTimestamp = (isoString: string) => {
    const date = new Date(isoString);
    return `${date.toLocaleDateString()} at ${date.toLocaleTimeString()}`;
};

const ActivityPage: React.FC<ActivityPageProps> = ({ activityLog, searchTerm }) => {
    const [currentPage, setCurrentPage] = useState(1);

    const filteredLog = useMemo(() => {
        return activityLog.filter(log =>
            log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.type.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [activityLog, searchTerm]);
    
    const totalPages = Math.ceil(filteredLog.length / ITEMS_PER_PAGE);
    const paginatedLog = filteredLog.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);
    
    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            setCurrentPage(page);
        }
    };

    return (
        <div>
             <h2 className="text-2xl font-semibold text-text-primary dark:text-dark-text-primary mb-6 sr-only">Activity Log</h2>
            <div className="bg-card-bg dark:bg-dark-card-bg shadow-md rounded-lg overflow-hidden">
                <div className="p-4 border-b dark:border-gray-700">
                    <h3 className="text-lg font-semibold text-text-primary dark:text-dark-text-primary">Recent Activities</h3>
                </div>
                <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                    {paginatedLog.map(log => (
                        <li key={log.id} className="p-4 flex items-start space-x-4 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                            <div className="flex-shrink-0 mt-1 p-2 bg-gray-100 dark:bg-gray-800 rounded-full">
                                {getActivityIcon(log.type)}
                            </div>
                            <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary dark:text-dark-text-primary">{log.details}</p>
                                <p className="text-sm text-text-secondary dark:text-dark-text-secondary">
                                    by <span className="font-medium">{log.user}</span> on {formatTimestamp(log.timestamp)}
                                </p>
                            </div>
                        </li>
                    ))}
                </ul>
                 {filteredLog.length === 0 && (
                    <div className="text-center py-10 text-text-secondary dark:text-dark-text-secondary">
                        No activities found.
                    </div>
                )}
            </div>
            <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
            />
        </div>
    );
};

export default ActivityPage;