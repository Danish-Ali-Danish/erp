import React, { useState, useMemo } from 'react';
import { Employee, EmployeeStatus } from '../types';
import { ChevronUpIcon, ChevronDownIcon, PencilIcon, TrashIcon, ExportIcon } from './icons';
import AddEmployeeModal from './AddEmployeeModal';
import EditEmployeeModal from './EditEmployeeModal';
import Pagination from './Pagination';

type SortKey = keyof Employee;

const statusColor = (status: EmployeeStatus) => {
    switch (status) {
      case EmployeeStatus.Active:
        return 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300';
      case EmployeeStatus.OnLeave:
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300';
      case EmployeeStatus.Terminated:
        return 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
};

interface EmployeeTableProps {
    employees: Employee[];
    onEdit: (employee: Employee) => void;
    onDelete: (employee: Employee) => void;
}

const EmployeeTable: React.FC<EmployeeTableProps> = ({ employees, onEdit, onDelete }) => {
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'ascending' | 'descending' } | null>({ key: 'name', direction: 'ascending' });
    
    const sortedEmployees = useMemo(() => {
        let sortableItems = [...employees];
        if (sortConfig !== null) {
            sortableItems.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? -1 : 1;
                }
                if (a[sortConfig.key] > b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableItems;
    }, [employees, sortConfig]);

    const requestSort = (key: SortKey) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (key: SortKey) => {
        if (!sortConfig || sortConfig.key !== key) {
            return <ChevronUpIcon className="w-4 h-4 text-gray-400 invisible group-hover:visible" />;
        }
        return sortConfig.direction === 'ascending' ? <ChevronUpIcon className="w-4 h-4" /> : <ChevronDownIcon className="w-4 h-4" />;
    };

    const headers: { key: SortKey, label: string }[] = [
        { key: 'name', label: 'Name' },
        { key: 'role', label: 'Role' },
        { key: 'department', label: 'Department' },
        { key: 'startDate', label: 'Start Date' },
    ];

    return (
        <div className="bg-card-bg dark:bg-dark-card-bg shadow-md rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-800">
                    <tr>
                        {headers.map((header) => (
                            <th key={header.key} scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">
                                <button onClick={() => requestSort(header.key)} className="group flex items-center space-x-1">
                                    <span>{header.label}</span>
                                    {getSortIcon(header.key)}
                                </button>
                            </th>
                        ))}
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Status</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200 dark:bg-dark-card-bg dark:divide-gray-700">
                    {sortedEmployees.map((employee) => (
                    <tr key={employee.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                        <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-text-primary dark:text-dark-text-primary">{employee.name}</div>
                            <div className="text-sm text-text-secondary dark:text-dark-text-secondary">{employee.email}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{employee.role}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{employee.department}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{employee.startDate}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColor(employee.status)}`}>
                                {employee.status}
                            </span>
                        </td>
                         <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div className="flex items-center space-x-2">
                                <button onClick={() => onEdit(employee)} className="text-primary-600 hover:text-primary-900 dark:text-primary-400 dark:hover:text-primary-200 transition duration-150 ease-in-out">
                                    <PencilIcon className="w-5 h-5"/>
                                </button>
                                <button onClick={() => onDelete(employee)} className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-200 transition duration-150 ease-in-out">
                                    <TrashIcon className="w-5 h-5"/>
                                </button>
                            </div>
                        </td>
                    </tr>
                    ))}
                </tbody>
            </table>
            </div>
             {employees.length === 0 && (
                <div className="text-center py-10 text-text-secondary dark:text-dark-text-secondary">
                    No employees found.
                </div>
            )}
        </div>
    );
};

interface HRPageProps {
    employees: Employee[];
    onAddEmployee: (newEmployee: Omit<Employee, 'id' | 'startDate'>) => void;
    onUpdateEmployee: (updatedEmployee: Employee) => void;
    onDeleteEmployee: (employee: Employee) => void;
    searchTerm: string;
}

const ITEMS_PER_PAGE = 10;

const HRPage: React.FC<HRPageProps> = ({ employees, onAddEmployee, onUpdateEmployee, onDeleteEmployee, searchTerm }) => {
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const filteredEmployees = useMemo(() => {
        return employees.filter(e =>
            e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            e.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            e.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
            e.department.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [employees, searchTerm]);

    const totalPages = Math.ceil(filteredEmployees.length / ITEMS_PER_PAGE);
    const paginatedEmployees = filteredEmployees.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            setCurrentPage(page);
        }
    };
    
    const handleUpdate = (updatedEmployee: Employee) => {
        onUpdateEmployee(updatedEmployee);
        setEditingEmployee(null);
    };

    const handleDelete = (employee: Employee) => {
        if (window.confirm(`Are you sure you want to delete ${employee.name}?`)) {
            onDeleteEmployee(employee);
        }
    };
    
    const handleExport = () => {
        const csvHeaders = ["ID", "Name", "Email", "Role", "Department", "Status", "Start Date"];
        const rows = filteredEmployees.map(e => [
            e.id,
            `"${e.name.replace(/"/g, '""')}"`,
            e.email,
            `"${e.role.replace(/"/g, '""')}"`,
            `"${e.department.replace(/"/g, '""')}"`,
            e.status,
            e.startDate
        ].join(','));

        const csvContent = "data:text/csv;charset=utf-8," + [csvHeaders.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "employees.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-semibold text-text-primary dark:text-dark-text-primary sr-only">Employee Management</h2>
                <div className="flex items-center gap-2">
                    <button
                        onClick={handleExport}
                        className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-md hover:bg-gray-700 dark:bg-gray-500 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-150"
                    >
                        <ExportIcon className="w-4 h-4" />
                        Export
                    </button>
                    <button
                        onClick={() => setIsAddModalOpen(true)}
                        className="px-5 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition duration-150"
                    >
                        Add Employee
                    </button>
                </div>
            </div>
            <EmployeeTable
                employees={paginatedEmployees}
                onEdit={setEditingEmployee}
                onDelete={handleDelete}
            />
            <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
            />

            {isAddModalOpen && (
                <AddEmployeeModal
                    onClose={() => setIsAddModalOpen(false)}
                    onAddEmployee={onAddEmployee}
                />
            )}

            {editingEmployee && (
                <EditEmployeeModal
                    employee={editingEmployee}
                    onClose={() => setEditingEmployee(null)}
                    onUpdateEmployee={handleUpdate}
                />
            )}
        </div>
    );
};

export default HRPage;