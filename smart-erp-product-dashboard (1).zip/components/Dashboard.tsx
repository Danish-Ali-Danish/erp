import React from 'react';
import { Product, StockStatus, SaleStatus, Sale, Customer } from '../types';
import StatCard from './StatCard';
import SalesChart from './SalesChart';
import { ProductsIcon, DollarIcon, BoxIcon, CustomersIcon } from './icons';
import { salesDataForChart } from '../types';

const RecentProducts: React.FC<{products: Product[]}> = ({ products }) => {
    const recent = [...products].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 5);

    const statusColor = (status: StockStatus) => {
        switch (status) {
          case StockStatus.InStock:
            return 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300';
          case StockStatus.LowStock:
            return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300';
          case StockStatus.OutOfStock:
            return 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300';
          default:
            return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
        }
    };

    return (
        <div className="bg-card-bg dark:bg-dark-card-bg shadow-md rounded-lg overflow-hidden h-full">
            <h3 className="text-lg font-semibold text-text-primary dark:text-dark-text-primary p-4 border-b dark:border-gray-700">Recent Products</h3>
            <div className="overflow-x-auto">
                <table className="min-w-full">
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {recent.map(product => (
                            <tr key={product.id}>
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="text-sm font-medium text-text-primary dark:text-dark-text-primary">{product.name}</div>
                                    <div className="text-sm text-text-secondary dark:text-dark-text-secondary">{product.category}</div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right">
                                     <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColor(product.status)}`}>
                                        {product.status}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

interface DashboardProps {
    products: Product[];
    sales: Sale[];
    customers: Customer[];
}

const Dashboard: React.FC<DashboardProps> = ({ products, sales, customers }) => {
    const totalRevenue = sales.filter(s => s.status === SaleStatus.Paid).reduce((acc, s) => acc + s.amount, 0);
    const totalStock = products.reduce((acc, p) => acc + p.stock, 0);
    const totalProducts = products.length;
    const totalCustomers = customers.length;

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <StatCard title="Total Revenue" value={`$${totalRevenue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`} icon={DollarIcon} />
                <StatCard title="Total Products" value={totalProducts.toString()} icon={ProductsIcon} />
                <StatCard title="Total Stock Units" value={totalStock.toLocaleString()} icon={BoxIcon} />
                <StatCard title="Total Customers" value={totalCustomers.toLocaleString()} icon={CustomersIcon} />
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <SalesChart data={salesDataForChart} />
                </div>
                <div>
                    <RecentProducts products={products} />
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
