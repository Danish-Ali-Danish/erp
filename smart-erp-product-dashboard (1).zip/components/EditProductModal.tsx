import React, { useState, useEffect } from 'react';
import { Product, Category } from '../types';
import { CloseIcon } from './icons';

interface EditProductModalProps {
  product: Product;
  onClose: () => void;
  onUpdateProduct: (product: Product) => void;
}

const EditProductModal: React.FC<EditProductModalProps> = ({ product, onClose, onUpdateProduct }) => {
  const [formData, setFormData] = useState<Product>(product);
  const [error, setError] = useState('');

  useEffect(() => {
    setFormData(product);
  }, [product]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleNumericChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value === '' ? '' : Number(value) }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isNaN(Number(formData.price)) || isNaN(Number(formData.stock)) || !formData.name.trim() || !formData.description.trim()) {
        setError('Please fill all fields with valid values.');
        return;
    }
    
    onUpdateProduct({
        ...formData,
        price: Number(formData.price),
        stock: Number(formData.stock)
    });
    onClose();
  };
  
  const inputStyles = "mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center p-4">
      <div className="bg-white dark:bg-dark-card-bg rounded-lg shadow-xl w-full max-w-2xl max-h-full overflow-y-auto">
        <div className="flex justify-between items-center p-5 border-b dark:border-gray-700">
          <h3 className="text-xl font-semibold text-text-primary dark:text-dark-text-primary">Edit Product</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Product Name</label>
            <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className={inputStyles} required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Category</label>
              <select id="category" name="category" value={formData.category} onChange={handleChange} className={inputStyles}>
                {Object.values(Category).map(cat => <option key={cat} value={cat}>{cat}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="price" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Price</label>
              <input type="number" id="price" name="price" value={formData.price} onChange={handleNumericChange} className={inputStyles} required step="0.01" min="0" />
            </div>
          </div>
          <div>
            <label htmlFor="stock" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Stock Quantity</label>
            <input type="number" id="stock" name="stock" value={formData.stock} onChange={handleNumericChange} className={inputStyles} required min="0"/>
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Product Description</label>
            <textarea id="description" name="description" value={formData.description} onChange={handleChange} rows={4} className={inputStyles} required />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <div className="flex justify-end pt-4 space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-text-secondary rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:text-dark-text-secondary dark:hover:bg-gray-500">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProductModal;
