import React, { useState, useCallback } from 'react';
import { Product, Category } from '../types';
import { generateDescription } from '../services/geminiService';
import { CloseIcon, SparklesIcon } from './icons';

interface AddProductModalProps {
  onClose: () => void;
  onAddProduct: (product: Omit<Product, 'id' | 'status' | 'createdAt'>) => void;
}

const AddProductModal: React.FC<AddProductModalProps> = ({ onClose, onAddProduct }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<Category>(Category.Electronics);
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('');
  const [keywords, setKeywords] = useState('');
  const [description, setDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGenerateDescription = useCallback(async () => {
    if (!name.trim()) {
      setError('Please enter a product name first.');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      const generatedDesc = await generateDescription(name, keywords);
      setDescription(generatedDesc);
    } catch (err) {
      setError('Failed to generate description. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [name, keywords]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseFloat(price);
    const stockNum = parseInt(stock, 10);

    if (isNaN(priceNum) || isNaN(stockNum) || !name.trim() || !description.trim()) {
        setError('Please fill all fields with valid values.');
        return;
    }

    onAddProduct({
      name,
      category,
      price: priceNum,
      stock: stockNum,
      description,
    });
    onClose();
  };
  
  const inputStyles = "mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center p-4">
      <div className="bg-white dark:bg-dark-card-bg rounded-lg shadow-xl w-full max-w-2xl max-h-full overflow-y-auto">
        <div className="flex justify-between items-center p-5 border-b dark:border-gray-700">
          <h3 className="text-xl font-semibold text-text-primary dark:text-dark-text-primary">Add New Product</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Product Name</label>
            <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} className={inputStyles} required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Category</label>
              <select id="category" value={category} onChange={(e) => setCategory(e.target.value as Category)} className={inputStyles}>
                {Object.values(Category).map(cat => <option key={cat} value={cat}>{cat}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="price" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Price</label>
              <input type="number" id="price" value={price} onChange={(e) => setPrice(e.target.value)} className={inputStyles} required step="0.01" min="0" />
            </div>
          </div>
          <div>
            <label htmlFor="stock" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Stock Quantity</label>
            <input type="number" id="stock" value={stock} onChange={(e) => setStock(e.target.value)} className={inputStyles} required min="0"/>
          </div>
          <div className="p-4 bg-primary-50 dark:bg-gray-800 rounded-lg">
            <label htmlFor="keywords" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">AI Description Helper</label>
            <p className="text-xs text-text-secondary dark:text-dark-text-secondary mb-2">Enter keywords to guide the AI, e.g., "eco-friendly, durable, for kids".</p>
            <div className="flex items-center gap-2">
              <input type="text" id="keywords" value={keywords} onChange={(e) => setKeywords(e.target.value)} placeholder="eco-friendly, durable..." className={inputStyles} />
              <button type="button" onClick={handleGenerateDescription} disabled={isLoading} className="flex items-center justify-center px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:bg-primary-300 transition duration-150">
                {isLoading ? (
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  <>
                    <SparklesIcon className="w-5 h-5 mr-2" />
                    Generate
                  </>
                )}
              </button>
            </div>
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Product Description</label>
            <textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={4} className={inputStyles} required />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <div className="flex justify-end pt-4 space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-text-secondary rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:text-dark-text-secondary dark:hover:bg-gray-500">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700">Add Product</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddProductModal;