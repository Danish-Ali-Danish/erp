// --- ENUMS ---

export enum Category {
  Electronics = 'Electronics',
  Clothing = 'Clothing',
  HomeGoods = 'Home Goods',
  Books = 'Books',
  Groceries = 'Groceries',
}

export enum StockStatus {
    InStock = 'In Stock',
    LowStock = 'Low Stock',
    OutOfStock = 'Out of Stock',
}

export enum SaleStatus {
  Paid = 'Paid',
  Pending = 'Pending',
  Overdue = 'Overdue',
}

export enum EmployeeStatus {
    Active = 'Active',
    OnLeave = 'On Leave',
    Terminated = 'Terminated',
}

export enum NotificationType {
    Stock = 'Stock',
    Sale = 'Sale',
    System = 'System'
}

export enum ActivityType {
    ProductCreated = 'ProductCreated',
    ProductUpdated = 'ProductUpdated',
    ProductDeleted = 'ProductDeleted',
    CustomerCreated = 'CustomerCreated',
    CustomerUpdated = 'CustomerUpdated',
    CustomerDeleted = 'CustomerDeleted',
    SaleCreated = 'SaleCreated',
    EmployeeCreated = 'EmployeeCreated',
    EmployeeUpdated = 'EmployeeUpdated',
    EmployeeDeleted = 'EmployeeDeleted',
    SystemReset = 'SystemReset',
}

// --- INTERFACES ---

export interface Product {
  id: string;
  name: string;
  category: Category;
  stock: number;
  price: number;
  description: string;
  status: StockStatus;
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  totalSpent: number;
  joinedAt: string;
}

export interface SaleProductDetail {
    productId: string;
    quantity: number;
    unitPrice: number;
}
export interface Sale {
  id: string;
  customerName: string;
  date: string;
  amount: number;
  status: SaleStatus;
  products: SaleProductDetail[];
}

export interface Employee {
    id: string;
    name: string;
    email: string;
    role: string;
    department: string;
    status: EmployeeStatus;
    startDate: string;
}

export interface Notification {
    id: string;
    type: NotificationType;
    message: string;
    date: string;
    read: boolean;
}

export interface ActivityLog {
    id: string;
    type: ActivityType;
    details: string;
    user: string;
    timestamp: string;
}


// --- MOCK DATA ---

export const initialProducts: Product[] = [
    { id: 'PROD001', name: 'Wireless Ergonomic Mouse', category: Category.Electronics, stock: 150, price: 49.99, description: 'A comfortable and responsive wireless mouse for all-day use.', status: StockStatus.InStock, createdAt: '2023-10-26' },
    { id: 'PROD002', name: 'Organic Cotton T-Shirt', category: Category.Clothing, stock: 300, price: 24.99, description: 'Soft, breathable, and sustainably sourced cotton t-shirt.', status: StockStatus.InStock, createdAt: '2023-10-25' },
    { id: 'PROD003', name: 'Smart LED Desk Lamp', category: Category.HomeGoods, stock: 45, price: 89.99, description: 'A modern desk lamp with adjustable brightness and color temperature.', status: StockStatus.LowStock, createdAt: '2023-10-24' },
    { id: 'PROD004', name: 'The Art of Programming', category: Category.Books, stock: 0, price: 59.99, description: 'A comprehensive guide to computer programming principles.', status: StockStatus.OutOfStock, createdAt: '2023-10-22' },
    { id: 'PROD005', name: 'Gourmet Coffee Beans', category: Category.Groceries, stock: 200, price: 19.99, description: 'Single-origin Arabica coffee beans with rich flavor notes.', status: StockStatus.InStock, createdAt: '2023-10-20' },
    { id: 'PROD006', name: 'Bluetooth Noise-Cancelling Headphones', category: Category.Electronics, stock: 80, price: 199.99, description: 'Immersive sound experience with active noise cancellation technology.', status: StockStatus.InStock, createdAt: '2023-10-19' },
    { id: 'PROD007', name: 'Yoga Mat', category: Category.HomeGoods, stock: 120, price: 34.99, description: 'Eco-friendly, non-slip yoga mat for all types of practice.', status: StockStatus.InStock, createdAt: '2023-10-18' },
    { id: 'PROD008', name: 'Classic Leather Wallet', category: Category.Clothing, stock: 25, price: 79.99, description: 'A timeless leather wallet with multiple card slots.', status: StockStatus.LowStock, createdAt: '2023-10-17' },
    { id: 'PROD009', name: 'Stainless Steel Water Bottle', category: Category.HomeGoods, stock: 500, price: 29.99, description: 'Keeps drinks cold for 24 hours or hot for 12 hours.', status: StockStatus.InStock, createdAt: '2023-10-16' },
    { id: 'PROD010', name: 'The Lord of the Rings Trilogy', category: Category.Books, stock: 50, price: 45.99, description: 'Box set of the epic high-fantasy novel.', status: StockStatus.LowStock, createdAt: '2023-10-15' },
];

export const initialCustomers: Customer[] = [
  { id: 'CUST001', name: 'John Doe', email: 'john.doe@example.com', phone: '555-1234', totalSpent: 1499.50, joinedAt: '2023-01-15' },
  { id: 'CUST002', name: 'Jane Smith', email: 'jane.smith@example.com', phone: '555-5678', totalSpent: 850.00, joinedAt: '2023-02-20' },
  { id: 'CUST003', name: 'Sam Wilson', email: 'sam.wilson@example.com', phone: '555-8765', totalSpent: 320.75, joinedAt: '2023-03-10' },
  { id: 'CUST004', name: 'Alice Johnson', email: 'alice.j@example.com', phone: '555-4321', totalSpent: 2500.00, joinedAt: '2022-11-05' },
  { id: 'CUST005', name: 'Bob Brown', email: 'bob.b@example.com', phone: '555-9999', totalSpent: 450.25, joinedAt: '2023-05-01' },
];

export const initialSales: Sale[] = [
  { id: 'SALE001', customerName: 'John Doe', date: '2023-10-25', amount: 124.99, status: SaleStatus.Paid, products: [{ productId: 'PROD001', quantity: 1, unitPrice: 49.99 }, { productId: 'PROD002', quantity: 3, unitPrice: 24.99 }] },
  { id: 'SALE002', customerName: 'Jane Smith', date: '2023-10-24', amount: 89.99, status: SaleStatus.Paid, products: [{ productId: 'PROD003', quantity: 1, unitPrice: 89.99 }] },
  { id: 'SALE003', customerName: 'Sam Wilson', date: '2023-10-22', amount: 45.50, status: SaleStatus.Pending, products: [{ productId: 'PROD005', quantity: 2, unitPrice: 19.99 }, { productId: 'PROD002', quantity: 1, unitPrice: 24.99 }] },
  { id: 'SALE004', customerName: 'Alice Johnson', date: '2023-10-20', amount: 350.00, status: SaleStatus.Paid, products: [{ productId: 'PROD006', quantity: 1, unitPrice: 199.99 }, { productId: 'PROD001', quantity: 3, unitPrice: 49.99 }] },
  { id: 'SALE005', customerName: 'John Doe', date: '2023-10-18', amount: 75.00, status: SaleStatus.Paid, products: [{ productId: 'PROD002', quantity: 3, unitPrice: 24.99 }] },
  { id: 'SALE006', customerName: 'Bob Brown', date: '2023-09-15', amount: 150.00, status: SaleStatus.Overdue, products: [{ productId: 'PROD001', quantity: 3, unitPrice: 49.99 }] },
];

export const initialEmployees: Employee[] = [
    { id: 'EMP001', name: 'Michael Scott', email: 'm.scott@example.com', role: 'Regional Manager', department: 'Management', status: EmployeeStatus.Active, startDate: '2018-04-01' },
    { id: 'EMP002', name: 'Dwight Schrute', email: 'd.schrute@example.com', role: 'Sales Representative', department: 'Sales', status: EmployeeStatus.Active, startDate: '2019-07-22' },
    { id: 'EMP003', name: 'Pam Beesly', email: 'p.beesly@example.com', role: 'Office Administrator', department: 'Administration', status: EmployeeStatus.OnLeave, startDate: '2020-02-10' },
    { id: 'EMP004', name: 'Jim Halpert', email: 'j.halpert@example.com', role: 'Sales Representative', department: 'Sales', status: EmployeeStatus.Active, startDate: '2019-08-15' },
    { id: 'EMP005', name: 'Angela Martin', email: 'a.martin@example.com', role: 'Accountant', department: 'Accounting', status: EmployeeStatus.Terminated, startDate: '2018-11-05' },
];

export const initialNotifications: Notification[] = [
    { id: 'NOTIF001', type: NotificationType.Stock, message: 'Stock for "Smart LED Desk Lamp" is low.', date: '2023-10-28', read: false },
    { id: 'NOTIF002', type: NotificationType.Sale, message: 'Invoice #SALE006 is overdue.', date: '2023-10-27', read: false },
    { id: 'NOTIF003', type: NotificationType.System, message: 'System maintenance scheduled for Oct 30.', date: '2023-10-26', read: true },
    { id: 'NOTIF004', type: NotificationType.Stock, message: '"The Art of Programming" is out of stock.', date: '2023-10-25', read: true },
];

export const salesDataForChart = [
    { name: 'Jan', sales: 4000 },
    { name: 'Feb', sales: 3000 },
    { name: 'Mar', sales: 5000 },
    { name: 'Apr', sales: 4500 },
    { name: 'May', sales: 6000 },
    { name: 'Jun', sales: 5500 },
];

export const initialActivityLog: ActivityLog[] = [
    { id: 'LOG1', type: ActivityType.ProductCreated, details: 'Created product: "Wireless Ergonomic Mouse"', user: 'Admin User', timestamp: '2023-10-26T10:00:00Z' },
    { id: 'LOG2', type: ActivityType.CustomerCreated, details: 'Created customer: "John Doe"', user: 'Admin User', timestamp: '2023-10-26T10:05:00Z' },
    { id: 'LOG3', type: ActivityType.SaleCreated, details: 'Created invoice #SALE001 for John Doe', user: 'Admin User', timestamp: '2023-10-26T10:15:00Z' },
    { id: 'LOG4', type: ActivityType.ProductUpdated, details: 'Updated stock for "Organic Cotton T-Shirt" to 297', user: 'Admin User', timestamp: '2023-10-26T10:15:05Z' },
];