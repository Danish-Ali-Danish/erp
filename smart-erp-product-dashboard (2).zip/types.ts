
// --- ENUMS ---

export enum Category {
  Electronics = 'Electronics',
  Clothing = 'Clothing',
  HomeGoods = 'Home Goods',
  Books = 'Books',
  Groceries = 'Groceries',
}

export enum StockStatus {
    InStock = 'In Stock',
    LowStock = 'Low Stock',
    OutOfStock = 'Out of Stock',
}

export enum SaleStatus {
  Paid = 'Paid',
  Pending = 'Pending',
  Overdue = 'Overdue',
}

export enum EmployeeStatus {
    Active = 'Active',
    OnLeave = 'On Leave',
    Terminated = 'Terminated',
}

export enum NotificationType {
    Stock = 'Stock',
    Sale = 'Sale',
    System = 'System'
}

export enum ActivityType {
    ProductCreated = 'ProductCreated',
    ProductUpdated = 'ProductUpdated',
    ProductDeleted = 'ProductDeleted',
    StockAdjusted = 'StockAdjusted',
    CustomerCreated = 'CustomerCreated',
    CustomerUpdated = 'CustomerUpdated',
    CustomerDeleted = 'CustomerDeleted',
    SaleCreated = 'SaleCreated',
    EmployeeCreated = 'EmployeeCreated',
    EmployeeUpdated = 'EmployeeUpdated',
    EmployeeDeleted = 'EmployeeDeleted',
    PurchaseOrderCreated = 'PurchaseOrderCreated',
    PurchaseOrderUpdated = 'PurchaseOrderUpdated',
    PurchaseOrderReceived = 'PurchaseOrderReceived',
    SystemReset = 'SystemReset',
}

export enum InventoryMovementType {
    In = 'In',
    Out = 'Out',
}

export enum PurchaseOrderStatus {
    Pending = 'Pending',
    Received = 'Received',
    Cancelled = 'Cancelled',
}

export enum Role {
    Admin = 'Admin',
    Manager = 'Manager',
    Staff = 'Staff',
}

// --- PERMISSIONS ---

export type Permission = 
  | 'view_dashboard'
  | 'view_products' | 'manage_products'
  | 'view_inventory'
  | 'view_suppliers' | 'manage_suppliers'
  | 'view_customers' | 'manage_customers'
  | 'view_sales' | 'manage_sales'
  | 'view_purchaseorders' | 'manage_purchaseorders'
  | 'view_hr' | 'manage_hr'
  | 'view_reports'
  | 'view_activity'
  | 'view_settings' | 'manage_settings'
  | 'export_data';

export const ROLES: Record<Role, Permission[]> = {
    [Role.Admin]: [
        'view_dashboard', 'view_products', 'manage_products', 'view_inventory',
        'view_suppliers', 'manage_suppliers', 'view_customers', 'manage_customers',
        'view_sales', 'manage_sales', 'view_purchaseorders', 'manage_purchaseorders',
        'view_hr', 'manage_hr', 'view_reports', 'view_activity', 'view_settings',
        'manage_settings', 'export_data'
    ],
    [Role.Manager]: [
        'view_dashboard', 'view_products', 'manage_products', 'view_inventory',
        'view_suppliers', 'view_customers', 'manage_customers', 'view_sales', 
        'manage_sales', 'view_purchaseorders', 'manage_purchaseorders', 'view_reports', 
        'view_activity', 'export_data'
    ],
    [Role.Staff]: [
        'view_dashboard', 'view_products', 'view_customers', 'view_sales', 'manage_sales'
    ]
};

// --- INTERFACES ---

export interface Supplier {
    id: string;
    name: string;
    contactPerson: string;
    email: string;
    phone: string;
}

export interface Product {
  id: string;
  name: string;
  category: Category;
  stock: number;
  price: number;
  description: string;
  status: StockStatus;
  createdAt: string;
  supplierId: string | null;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  totalSpent: number;
  joinedAt: string;
}

export interface SaleProductDetail {
    productId: string;
    quantity: number;
    unitPrice: number;
}
export interface Sale {
  id: string;
  customerName: string;
  date: string;
  amount: number;
  status: SaleStatus;
  products: SaleProductDetail[];
}

export interface Employee {
    id: string;
    name: string;
    email: string;
    role: Role; // Changed from string to Role enum
    department: string;
    status: EmployeeStatus;
    startDate: string;
}

export interface Notification {
    id: string;
    type: NotificationType;
    message: string;
    date: string;
    read: boolean;
}

export interface ActivityLog {
    id:string;
    type: ActivityType;
    details: string;
    user: string;
    timestamp: string;
}

export interface InventoryMovement {
    id: string;
    productId: string;
    productName: string;
    quantityChange: number;
    newQuantity: number;
    type: InventoryMovementType;
    reason: string;
    timestamp: string;
}

export interface PurchaseOrderProductDetail {
    productId: string;
    quantity: number;
    unitPrice: number;
}

export interface PurchaseOrder {
    id: string;
    supplierId: string;
    supplierName: string;
    date: string;
    status: PurchaseOrderStatus;
    products: PurchaseOrderProductDetail[];
    totalAmount: number;
}


// --- MOCK DATA ---
export const initialSuppliers: Supplier[] = [
    { id: 'SUP001', name: 'ElectroSource', contactPerson: 'Sarah Chen', email: 'sales@electrosource.com', phone: '111-222-3333' },
    { id: 'SUP002', name: 'Fashion Hub', contactPerson: 'Mike Ross', email: 'orders@fashionhub.com', phone: '222-333-4444' },
    { id: 'SUP003', name: 'Home Essentials Co.', contactPerson: 'Laura Palmer', email: 'laura.p@homeessentials.com', phone: '333-444-5555' },
];

export const initialProducts: Product[] = [
    { id: 'PROD001', name: 'Wireless Ergonomic Mouse', category: Category.Electronics, stock: 150, price: 49.99, description: 'A comfortable and responsive wireless mouse for all-day use.', status: StockStatus.InStock, createdAt: '2023-10-26', supplierId: 'SUP001' },
    { id: 'PROD002', name: 'Organic Cotton T-Shirt', category: Category.Clothing, stock: 300, price: 24.99, description: 'Soft, breathable, and sustainably sourced cotton t-shirt.', status: StockStatus.InStock, createdAt: '2023-10-25', supplierId: 'SUP002' },
    { id: 'PROD003', name: 'Smart LED Desk Lamp', category: Category.HomeGoods, stock: 45, price: 89.99, description: 'A modern desk lamp with adjustable brightness and color temperature.', status: StockStatus.LowStock, createdAt: '2023-10-24', supplierId: 'SUP003' },
    { id: 'PROD004', name: 'The Art of Programming', category: Category.Books, stock: 0, price: 59.99, description: 'A comprehensive guide to computer programming principles.', status: StockStatus.OutOfStock, createdAt: '2023-10-22', supplierId: null },
    { id: 'PROD005', name: 'Gourmet Coffee Beans', category: Category.Groceries, stock: 200, price: 19.99, description: 'Single-origin Arabica coffee beans with rich flavor notes.', status: StockStatus.InStock, createdAt: '2023-10-20', supplierId: null },
    { id: 'PROD006', name: 'Bluetooth Noise-Cancelling Headphones', category: Category.Electronics, stock: 80, price: 199.99, description: 'Immersive sound experience with active noise cancellation technology.', status: StockStatus.InStock, createdAt: '2023-10-19', supplierId: 'SUP001' },
    { id: 'PROD007', name: 'Yoga Mat', category: Category.HomeGoods, stock: 120, price: 34.99, description: 'Eco-friendly, non-slip yoga mat for all types of practice.', status: StockStatus.InStock, createdAt: '2023-10-18', supplierId: 'SUP003' },
    { id: 'PROD008', name: 'Classic Leather Wallet', category: Category.Clothing, stock: 25, price: 79.99, description: 'A timeless leather wallet with multiple card slots.', status: StockStatus.LowStock, createdAt: '2023-10-17', supplierId: 'SUP002' },
    { id: 'PROD009', name: 'Stainless Steel Water Bottle', category: Category.HomeGoods, stock: 500, price: 29.99, description: 'Keeps drinks cold for 24 hours or hot for 12 hours.', status: StockStatus.InStock, createdAt: '2023-10-16', supplierId: 'SUP003' },
    { id: 'PROD010', name: 'The Lord of the Rings Trilogy', category: Category.Books, stock: 50, price: 45.99, description: 'Box set of the epic high-fantasy novel.', status: StockStatus.LowStock, createdAt: '2023-10-15', supplierId: null },
];

export const initialCustomers: Customer[] = [
  { id: 'CUST001', name: 'John Doe', email: 'john.doe@example.com', phone: '555-1234', totalSpent: 1499.50, joinedAt: '2023-01-15' },
  { id: 'CUST002', name: 'Jane Smith', email: 'jane.smith@example.com', phone: '555-5678', totalSpent: 850.00, joinedAt: '2023-02-20' },
  { id: 'CUST003', name: 'Sam Wilson', email: 'sam.wilson@example.com', phone: '555-8765', totalSpent: 320.75, joinedAt: '2023-03-10' },
  { id: 'CUST004', name: 'Alice Johnson', email: 'alice.j@example.com', phone: '555-4321', totalSpent: 2500.00, joinedAt: '2022-11-05' },
  { id: 'CUST005', name: 'Bob Brown', email: 'bob.b@example.com', phone: '555-9999', totalSpent: 450.25, joinedAt: '2023-05-01' },
];

export const initialSales: Sale[] = [
  { id: 'SALE001', customerName: 'John Doe', date: '2023-10-25', amount: 124.99, status: SaleStatus.Paid, products: [{ productId: 'PROD001', quantity: 1, unitPrice: 49.99 }, { productId: 'PROD002', quantity: 3, unitPrice: 24.99 }] },
  { id: 'SALE002', customerName: 'Jane Smith', date: '2023-10-24', amount: 89.99, status: SaleStatus.Paid, products: [{ productId: 'PROD003', quantity: 1, unitPrice: 89.99 }] },
  { id: 'SALE003', customerName: 'Sam Wilson', date: '2023-10-22', amount: 45.50, status: SaleStatus.Pending, products: [{ productId: 'PROD005', quantity: 2, unitPrice: 19.99 }, { productId: 'PROD002', quantity: 1, unitPrice: 24.99 }] },
  { id: 'SALE004', customerName: 'Alice Johnson', date: '2023-10-20', amount: 350.00, status: SaleStatus.Paid, products: [{ productId: 'PROD006', quantity: 1, unitPrice: 199.99 }, { productId: 'PROD001', quantity: 3, unitPrice: 49.99 }] },
  { id: 'SALE005', customerName: 'John Doe', date: '2023-10-18', amount: 75.00, status: SaleStatus.Paid, products: [{ productId: 'PROD002', quantity: 3, unitPrice: 24.99 }] },
  { id: 'SALE006', customerName: 'Bob Brown', date: '2023-09-15', amount: 150.00, status: SaleStatus.Overdue, products: [{ productId: 'PROD001', quantity: 3, unitPrice: 49.99 }] },
];

export const initialEmployees: Employee[] = [
    { id: 'EMP001', name: 'Michael Scott', email: 'm.scott@example.com', role: Role.Admin, department: 'Management', status: EmployeeStatus.Active, startDate: '2018-04-01' },
    { id: 'EMP002', name: 'Dwight Schrute', email: 'd.schrute@example.com', role: Role.Manager, department: 'Sales', status: EmployeeStatus.Active, startDate: '2019-07-22' },
    { id: 'EMP003', name: 'Pam Beesly', email: 'p.beesly@example.com', role: Role.Staff, department: 'Administration', status: EmployeeStatus.OnLeave, startDate: '2020-02-10' },
    { id: 'EMP004', name: 'Jim Halpert', email: 'j.halpert@example.com', role: Role.Staff, department: 'Sales', status: EmployeeStatus.Active, startDate: '2019-08-15' },
    { id: 'EMP005', name: 'Angela Martin', email: 'a.martin@example.com', role: Role.Manager, department: 'Accounting', status: EmployeeStatus.Terminated, startDate: '2018-11-05' },
];

export const initialNotifications: Notification[] = [
    { id: 'NOTIF001', type: NotificationType.Stock, message: 'Stock for "Smart LED Desk Lamp" is low.', date: '2023-10-28', read: false },
    { id: 'NOTIF002', type: NotificationType.Sale, message: 'Invoice #SALE006 is overdue.', date: '2023-10-27', read: false },
    { id: 'NOTIF003', type: NotificationType.System, message: 'System maintenance scheduled for Oct 30.', date: '2023-10-26', read: true },
    { id: 'NOTIF004', type: NotificationType.Stock, message: '"The Art of Programming" is out of stock.', date: '2023-10-25', read: true },
];

export const salesDataForChart = [
    { name: 'Jan', sales: 4000 },
    { name: 'Feb', sales: 3000 },
    { name: 'Mar', sales: 5000 },
    { name: 'Apr', sales: 4500 },
    { name: 'May', sales: 6000 },
    { name: 'Jun', sales: 5500 },
];

export const initialActivityLog: ActivityLog[] = [
    { id: 'LOG1', type: ActivityType.ProductCreated, details: 'Created product: "Wireless Ergonomic Mouse"', user: 'Admin User', timestamp: '2023-10-26T10:00:00Z' },
    { id: 'LOG2', type: ActivityType.CustomerCreated, details: 'Created customer: "John Doe"', user: 'Admin User', timestamp: '2023-10-26T10:05:00Z' },
    { id: 'LOG3', type: ActivityType.SaleCreated, details: 'Created invoice #SALE001 for John Doe', user: 'Admin User', timestamp: '2023-10-26T10:15:00Z' },
    { id: 'LOG4', type: ActivityType.StockAdjusted, details: 'Adjusted stock for "Organic Cotton T-Shirt" by -3. Reason: Sale #SALE001', user: 'System', timestamp: '2023-10-26T10:15:05Z' },
];

export const initialInventoryMovements: InventoryMovement[] = [
    { id: 'IM001', productId: 'PROD001', productName: 'Wireless Ergonomic Mouse', quantityChange: 150, newQuantity: 150, type: InventoryMovementType.In, reason: 'Initial stock', timestamp: '2023-10-26T09:00:00Z' },
    { id: 'IM002', productId: 'PROD002', productName: 'Organic Cotton T-Shirt', quantityChange: 300, newQuantity: 300, type: InventoryMovementType.In, reason: 'Initial stock', timestamp: '2023-10-25T09:00:00Z' },
    { id: 'IM003', productId: 'PROD001', productName: 'Wireless Ergonomic Mouse', quantityChange: -1, newQuantity: 149, type: InventoryMovementType.Out, reason: 'Sale #SALE001', timestamp: '2023-10-25T14:00:00Z' },
    { id: 'IM004', productId: 'PROD002', productName: 'Organic Cotton T-Shirt', quantityChange: -3, newQuantity: 297, type: InventoryMovementType.Out, reason: 'Sale #SALE001', timestamp: '2023-10-25T14:00:00Z' },
];

export const initialPurchaseOrders: PurchaseOrder[] = [
    { id: 'PO001', supplierId: 'SUP001', supplierName: 'ElectroSource', date: '2023-10-20', status: PurchaseOrderStatus.Received, totalAmount: 11997.5, products: [{ productId: 'PROD006', quantity: 50, unitPrice: 199.99 }, { productId: 'PROD001', quantity: 40, unitPrice: 49.99 }] },
    { id: 'PO002', supplierId: 'SUP002', supplierName: 'Fashion Hub', date: '2023-10-28', status: PurchaseOrderStatus.Pending, totalAmount: 3248.5, products: [{ productId: 'PROD002', quantity: 50, unitPrice: 24.99 }, { productId: 'PROD008', quantity: 25, unitPrice: 79.99 }] },
];