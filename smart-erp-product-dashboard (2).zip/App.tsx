
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import ProductsPage from './components/ProductsPage';
import CustomerPage from './components/CustomerPage';
import SalesPage from './components/SalesPage';
import HRPage from './components/HRPage';
import ReportsPage from './components/ReportsPage';
import SettingsPage from './components/SettingsPage';
import ActivityPage from './components/ActivityPage';
import InventoryPage from './components/InventoryPage';
import SuppliersPage from './components/SuppliersPage';
import PurchaseOrdersPage from './components/PurchaseOrdersPage';
import LoginScreen from './components/LoginScreen';
import { useAuth } from './auth/AuthContext';
import { 
    initialProducts, initialCustomers, initialSales, initialEmployees, initialActivityLog, initialSuppliers, initialInventoryMovements, initialPurchaseOrders,
    Product, Customer, Sale, Employee, ActivityLog, Supplier, InventoryMovement, PurchaseOrder,
    ActivityType, StockStatus, SaleStatus, InventoryMovementType, PurchaseOrderStatus 
} from './types';

export type Page = 'Dashboard' | 'Products' | 'Customers' | 'Sales' | 'HR' | 'Reports' | 'Activity' | 'Settings' | 'Inventory' | 'Suppliers' | 'PurchaseOrders';
export type Theme = 'light' | 'dark';

const App: React.FC = () => {
  const { currentUser, hasPermission } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activePage, setActivePage] = useState<Page>('Dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [theme, setTheme] = useState<Theme>(() => {
      if (typeof window !== 'undefined' && localStorage.getItem('theme')) {
          return localStorage.getItem('theme') as Theme;
      }
      if (typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches) {
          return 'dark';
      }
      return 'light';
  });

  // Centralized State
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [sales, setSales] = useState<Sale[]>(initialSales);
  const [employees, setEmployees] = useState<Employee[]>(initialEmployees);
  const [activityLog, setActivityLog] = useState<ActivityLog[]>(initialActivityLog);
  const [suppliers, setSuppliers] = useState<Supplier[]>(initialSuppliers);
  const [inventoryMovements, setInventoryMovements] = useState<InventoryMovement[]>(initialInventoryMovements);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(initialPurchaseOrders);
  
  const logActivity = (type: ActivityType, details: string) => {
    if (!currentUser) return;
    const newLog: ActivityLog = {
      id: `LOG${Date.now()}`,
      type,
      details,
      user: currentUser.name,
      timestamp: new Date().toISOString(),
    };
    setActivityLog(prev => [newLog, ...prev]);
  };
  
  const logInventoryMovement = (productId: string, productName: string, quantityChange: number, newQuantity: number, type: InventoryMovementType, reason: string) => {
    const newMovement: InventoryMovement = {
        id: `IM${Date.now()}-${productId}`,
        productId,
        productName,
        quantityChange,
        newQuantity,
        type,
        reason,
        timestamp: new Date().toISOString(),
    };
    setInventoryMovements(prev => [newMovement, ...prev]);
  };

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);
  
  useEffect(() => {
    // If user's permissions change (e.g., logout), redirect if they're on a now-forbidden page
    if (currentUser && !hasPermission(`view_${activePage.toLowerCase()}` as any)) {
      setActivePage('Dashboard');
    }
  }, [currentUser, activePage, hasPermission]);


  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const handlePageChange = (page: Page) => {
    setActivePage(page);
    setSearchTerm(''); // Reset search when changing pages
  };

  // --- Product CRUD and Stock Handlers ---
  const handleAddProduct = (newProduct: Omit<Product, 'id' | 'status' | 'createdAt'>) => {
      const productToAdd: Product = {
          ...newProduct,
          id: `PROD${Date.now()}`,
          status: newProduct.stock > 50 ? StockStatus.InStock : newProduct.stock > 0 ? StockStatus.LowStock : StockStatus.OutOfStock,
          createdAt: new Date().toISOString().split('T')[0],
      };
      setProducts(prev => [productToAdd, ...prev]);
      logActivity(ActivityType.ProductCreated, `Created product: "${productToAdd.name}"`);
      if (productToAdd.stock > 0) {
        logInventoryMovement(productToAdd.id, productToAdd.name, productToAdd.stock, productToAdd.stock, InventoryMovementType.In, "Initial stock");
      }
  };
  const handleUpdateProduct = (updatedProduct: Product) => {
      const newStatus = updatedProduct.stock > 50 ? StockStatus.InStock : updatedProduct.stock > 0 ? StockStatus.LowStock : StockStatus.OutOfStock;
      setProducts(products.map(p => p.id === updatedProduct.id ? { ...updatedProduct, status: newStatus } : p));
      logActivity(ActivityType.ProductUpdated, `Updated product info: "${updatedProduct.name}"`);
  };
  const handleDeleteProduct = (product: Product) => {
    setProducts(products.filter(p => p.id !== product.id));
    logActivity(ActivityType.ProductDeleted, `Deleted product: "${product.name}"`);
  };
  const handleStockAdjustment = (product: Product, newStock: number, reason: string) => {
    const quantityChange = newStock - product.stock;
    const movementType = quantityChange > 0 ? InventoryMovementType.In : InventoryMovementType.Out;
    
    const updatedProduct = { ...product, stock: newStock };
    handleUpdateProduct(updatedProduct);
    
    logInventoryMovement(product.id, product.name, quantityChange, newStock, movementType, reason);
    logActivity(ActivityType.StockAdjusted, `Adjusted stock for "${product.name}" by ${quantityChange}. Reason: ${reason}`);
  };

  // --- Customer CRUD Handlers ---
  const handleAddCustomer = (newCustomerData: Omit<Customer, 'id' | 'totalSpent' | 'joinedAt'>) => {
      const newCustomer: Customer = { ...newCustomerData, id: `CUST${Date.now()}`, totalSpent: 0, joinedAt: new Date().toISOString().split('T')[0] };
      setCustomers(prev => [newCustomer, ...prev]);
      logActivity(ActivityType.CustomerCreated, `Created customer: "${newCustomer.name}"`);
  };
  const handleUpdateCustomer = (updatedCustomer: Customer) => {
    setCustomers(customers.map(c => c.id === updatedCustomer.id ? updatedCustomer : c));
    logActivity(ActivityType.CustomerUpdated, `Updated customer: "${updatedCustomer.name}"`);
  };
  const handleDeleteCustomer = (customer: Customer) => {
    setCustomers(customers.filter(c => c.id !== customer.id));
    logActivity(ActivityType.CustomerDeleted, `Deleted customer: "${customer.name}"`);
  };
  
  // --- Employee CRUD Handlers ---
  const handleAddEmployee = (newEmployeeData: Omit<Employee, 'id' | 'startDate'>) => {
      const newEmployee: Employee = { ...newEmployeeData, id: `EMP${Date.now()}`, startDate: new Date().toISOString().split('T')[0] };
      setEmployees(prev => [newEmployee, ...prev]);
      logActivity(ActivityType.EmployeeCreated, `Added employee: "${newEmployee.name}"`);
  };
  const handleUpdateEmployee = (updatedEmployee: Employee) => {
    setEmployees(employees.map(e => e.id === updatedEmployee.id ? updatedEmployee : e));
    logActivity(ActivityType.EmployeeUpdated, `Updated employee: "${updatedEmployee.name}"`);
  };
  const handleDeleteEmployee = (employee: Employee) => {
    setEmployees(employees.filter(e => e.id !== employee.id));
    logActivity(ActivityType.EmployeeDeleted, `Deleted employee: "${employee.name}"`);
  };
  
  // --- Sales & Purchase Order Handlers ---
  const handleAddSale = (newSaleData: Omit<Sale, 'id' | 'date'>) => {
        const newSale: Sale = {
            ...newSaleData,
            id: `SALE${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
        };
        setSales(prev => [newSale, ...prev]);
        logActivity(ActivityType.SaleCreated, `Created invoice #${newSale.id} for ${newSale.customerName}`);
        
        const customer = customers.find(c => c.name === newSale.customerName);
        if (customer && newSale.status === SaleStatus.Paid) {
            const updatedCustomer = { ...customer, totalSpent: customer.totalSpent + newSale.amount };
            handleUpdateCustomer(updatedCustomer);
        }

        newSale.products.forEach(item => {
            const product = products.find(p => p.id === item.productId);
            if(product) {
                const newStock = product.stock - item.quantity;
                handleStockAdjustment(product, newStock, `Sale #${newSale.id}`);
            }
        });
    };
  
  const handleAddPurchaseOrder = (newPOData: Omit<PurchaseOrder, 'id' | 'date'>) => {
    const newPO: PurchaseOrder = {
        ...newPOData,
        id: `PO${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
    };
    setPurchaseOrders(prev => [newPO, ...prev]);
    logActivity(ActivityType.PurchaseOrderCreated, `Created PO #${newPO.id} for ${newPO.supplierName}`);
  };

  const handleUpdatePurchaseOrderStatus = (poId: string, newStatus: PurchaseOrderStatus) => {
    let poToUpdate: PurchaseOrder | undefined;
    const updatedPOs = purchaseOrders.map(po => {
        if (po.id === poId) {
            poToUpdate = { ...po, status: newStatus };
            return poToUpdate;
        }
        return po;
    });

    if (poToUpdate && newStatus === PurchaseOrderStatus.Received) {
        setPurchaseOrders(updatedPOs);
        poToUpdate.products.forEach(item => {
            const product = products.find(p => p.id === item.productId);
            if (product) {
                const newStock = product.stock + item.quantity;
                handleStockAdjustment(product, newStock, `Received from PO #${poToUpdate?.id}`);
            }
        });
        logActivity(ActivityType.PurchaseOrderReceived, `Marked PO #${poToUpdate.id} as Received. Stock updated.`);
    } else if (poToUpdate) {
        setPurchaseOrders(updatedPOs);
        logActivity(ActivityType.PurchaseOrderUpdated, `Updated PO #${poToUpdate.id} status to ${newStatus}.`);
    }
  };

  const handleResetData = () => {
    if (window.confirm('Are you sure you want to reset all application data? This action cannot be undone.')) {
        setProducts(initialProducts);
        setCustomers(initialCustomers);
        setSales(initialSales);
        setEmployees(initialEmployees);
        setActivityLog(initialActivityLog);
        setSuppliers(initialSuppliers);
        setInventoryMovements(initialInventoryMovements);
        setPurchaseOrders(initialPurchaseOrders);
        logActivity(ActivityType.SystemReset, "Application data has been reset");
        alert('Application data has been reset to its initial state.');
        setActivePage('Dashboard');
    }
  };
  
  const renderPage = () => {
    const pageProps = { searchTerm, onSearch: setSearchTerm };
    
    // Permission Check
    const viewPermission = `view_${activePage.toLowerCase()}` as any;
    if (!hasPermission(viewPermission)) {
        return <Dashboard products={products} sales={sales} customers={customers} />;
    }

    switch (activePage) {
      case 'Dashboard':
        return <Dashboard products={products} sales={sales} customers={customers} />;
      case 'Products':
        return <ProductsPage products={products} suppliers={suppliers} onAddProduct={handleAddProduct} onUpdateProduct={handleUpdateProduct} onDeleteProduct={handleDeleteProduct} onAdjustStock={handleStockAdjustment} {...pageProps} />;
      case 'Customers':
        return <CustomerPage customers={customers} onAddCustomer={handleAddCustomer} onUpdateCustomer={handleUpdateCustomer} onDeleteCustomer={handleDeleteCustomer} {...pageProps} />;
      case 'Sales':
        return <SalesPage sales={sales} products={products} customers={customers} onAddSale={handleAddSale} {...pageProps} />;
      case 'PurchaseOrders':
        return <PurchaseOrdersPage purchaseOrders={purchaseOrders} suppliers={suppliers} products={products} onAddPurchaseOrder={handleAddPurchaseOrder} onUpdateStatus={handleUpdatePurchaseOrderStatus} {...pageProps} />;
      case 'Inventory':
        return <InventoryPage inventoryMovements={inventoryMovements} {...pageProps} />;
      case 'Suppliers':
        return <SuppliersPage suppliers={suppliers} {...pageProps} />;
      case 'HR':
        return <HRPage employees={employees} onAddEmployee={handleAddEmployee} onUpdateEmployee={handleUpdateEmployee} onDeleteEmployee={handleDeleteEmployee} {...pageProps} />;
      case 'Reports':
        return <ReportsPage sales={sales} products={products} customers={customers} />;
      case 'Activity':
        return <ActivityPage activityLog={activityLog} {...pageProps} />;
      case 'Settings':
        return <SettingsPage onResetData={handleResetData} />;
      default:
        return <Dashboard products={products} sales={sales} customers={customers} />;
    }
  };

  if (!currentUser) {
      return <LoginScreen employees={employees} />;
  }

  return (
    <div className="flex h-screen bg-background dark:bg-dark-background">
      <Sidebar 
        sidebarOpen={sidebarOpen} 
        setSidebarOpen={setSidebarOpen} 
        activePage={activePage}
        setActivePage={handlePageChange}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
            setSidebarOpen={setSidebarOpen} 
            activePage={activePage} 
            theme={theme}
            toggleTheme={toggleTheme}
            searchTerm={searchTerm}
            onSearch={setSearchTerm}
            logActivity={logActivity}
        />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background dark:bg-dark-background">
          <div className="container mx-auto px-6 py-8">
            {renderPage()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;