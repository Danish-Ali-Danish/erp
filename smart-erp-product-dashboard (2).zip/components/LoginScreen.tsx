
import React from 'react';
import { Employee } from '../types';
import { useAuth } from '../auth/AuthContext';

interface LoginScreenProps {
  employees: Employee[];
}

const LoginScreen: React.FC<LoginScreenProps> = ({ employees }) => {
  const { login } = useAuth();

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900">
      <div className="w-full max-w-md p-8 space-y-8 bg-white dark:bg-dark-card-bg rounded-lg shadow-lg">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Welcome to SmartERP</h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">Please select a user to log in</p>
        </div>
        <div className="space-y-4">
          {employees.map((employee) => (
            <button
              key={employee.id}
              onClick={() => login(employee)}
              className="w-full flex items-center p-4 text-left bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-primary-100 dark:hover:bg-primary-900/50 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary-500"
            >
              <img
                className="w-12 h-12 rounded-full object-cover"
                src={`https://i.pravatar.cc/150?u=${employee.id}`}
                alt={employee.name}
              />
              <div className="ml-4">
                <p className="text-lg font-semibold text-gray-800 dark:text-gray-200">{employee.name}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{employee.role} - {employee.department}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;