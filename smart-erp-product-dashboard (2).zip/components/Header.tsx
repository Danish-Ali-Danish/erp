
import React from 'react';
import { Page, Theme } from '../App';
import { MenuIcon, LogoutIcon } from './icons';
import ThemeToggle from './ThemeToggle';
import Notifications from './Notifications';
import { useAuth } from '../auth/AuthContext';
import { ActivityType } from '../types';

interface HeaderProps {
  setSidebarOpen: (open: boolean) => void;
  activePage: Page;
  theme: Theme;
  toggleTheme: () => void;
  searchTerm: string;
  onSearch: (term: string) => void;
  logActivity: (type: ActivityType, details: string) => void;
}

const Header: React.FC<HeaderProps> = ({ setSidebarOpen, activePage, theme, toggleTheme, searchTerm, onSearch, logActivity }) => {
    const { currentUser, logout } = useAuth();
    
    const pageTitles: Record<Page, string> = {
        Dashboard: 'Dashboard Overview',
        Products: 'Product Management',
        Inventory: 'Inventory Log',
        Suppliers: 'Supplier Management',
        Customers: 'Customer Relationship Management',
        Sales: 'Sales & Invoices',
        PurchaseOrders: 'Purchase Orders',
        HR: 'Human Resources',
        Reports: 'Business Reports',
        Activity: 'Activity Log',
        Settings: 'System Settings',
    };

    const searchablePages: Page[] = ['Products', 'Customers', 'Sales', 'HR', 'Activity', 'Inventory', 'PurchaseOrders', 'Suppliers'];
    const showSearch = searchablePages.includes(activePage);
    
    const handleLogout = () => {
        if(currentUser) {
            // This is a placeholder for a more robust activity log
            // logActivity(ActivityType.Logout, `${currentUser.name} logged out.`);
            logout();
        }
    }

  return (
    <header className="flex justify-between items-center px-6 py-4 bg-header-bg dark:bg-dark-header-bg border-b dark:border-gray-700">
      <div className="flex items-center">
        <button onClick={() => setSidebarOpen(true)} className="text-gray-500 dark:text-dark-text-secondary focus:outline-none lg:hidden">
          <MenuIcon className="h-6 w-6" />
        </button>
        <h1 className="text-2xl font-semibold text-text-primary dark:text-dark-text-primary ml-4 lg:ml-0">{pageTitles[activePage]}</h1>
      </div>

      <div className="flex items-center gap-4">
        {showSearch && (
          <div className="relative">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center">
              <svg className="h-5 w-5 text-gray-500" viewBox="0 0 24 24" fill="none">
                <path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>

            <input
              className="w-full md:w-64 pl-10 pr-4 py-2 border rounded-md bg-gray-100 dark:bg-gray-700 dark:text-dark-text-primary dark:border-gray-600 focus:bg-white dark:focus:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-primary-500"
              type="text"
              placeholder={`Search in ${activePage}...`}
              value={searchTerm}
              onChange={(e) => onSearch(e.target.value)}
            />
          </div>
        )}
        <Notifications />
        <ThemeToggle theme={theme} onToggle={toggleTheme} />
        <div className="w-px h-6 bg-gray-300 dark:bg-gray-600"></div>
        <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-text-primary dark:text-dark-text-primary hidden sm:inline">{currentUser?.name}</span>
            <button
                onClick={handleLogout}
                title="Logout"
                className="p-2 rounded-full text-gray-500 dark:text-dark-text-secondary hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-dark-header-bg"
            >
                <LogoutIcon className="h-6 w-6"/>
            </button>
        </div>
      </div>
    </header>
  );
};

export default Header;