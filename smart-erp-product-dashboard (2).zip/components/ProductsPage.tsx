
import React, { useState, useMemo } from 'react';
import { Product, Category, Supplier } from '../types';
import ProductTable from './ProductTable';
import AddProductModal from './AddProductModal';
import EditProductModal from './EditProductModal';
import StockAdjustmentModal from './StockAdjustmentModal';
import Pagination from './Pagination';
import { ExportIcon } from './icons';
import { useAuth } from '../auth/AuthContext';

interface ProductsPageProps {
    products: Product[];
    suppliers: Supplier[];
    onAddProduct: (newProduct: Omit<Product, 'id' | 'status' | 'createdAt'>) => void;
    onUpdateProduct: (updatedProduct: Product) => void;
    onDeleteProduct: (product: Product) => void;
    onAdjustStock: (product: Product, newStock: number, reason: string) => void;
    searchTerm: string;
}

const ITEMS_PER_PAGE = 8;

const ProductsPage: React.FC<ProductsPageProps> = ({ products, suppliers, onAddProduct, onUpdateProduct, onDeleteProduct, onAdjustStock, searchTerm }) => {
    const { hasPermission } = useAuth();
    const canManage = hasPermission('manage_products');
    const canExport = hasPermission('export_data');

    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState<Product | null>(null);
    const [adjustingStockProduct, setAdjustingStockProduct] = useState<Product | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [filter, setFilter] = useState<Category | 'all'>('all');

    const filteredProducts = useMemo(() => {
        return products
            .filter(p => filter === 'all' || p.category === filter)
            .filter(p =>
                p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                p.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                p.id.toLowerCase().includes(searchTerm.toLowerCase())
            );
    }, [products, searchTerm, filter]);
    
    // Pagination logic
    const totalPages = Math.ceil(filteredProducts.length / ITEMS_PER_PAGE);
    const paginatedProducts = filteredProducts.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            setCurrentPage(page);
        }
    };
    
    const handleUpdate = (updatedProduct: Product) => {
        onUpdateProduct(updatedProduct);
        setEditingProduct(null);
    };

    const handleDelete = (product: Product) => {
        if (window.confirm(`Are you sure you want to delete ${product.name}?`)) {
            onDeleteProduct(product);
        }
    }
    
    const handleStockAdjustment = (product: Product, newStock: number, reason: string) => {
        onAdjustStock(product, newStock, reason);
        setAdjustingStockProduct(null);
    };
    
    const handleExport = () => {
        const csvHeaders = ["ID", "Name", "Category", "Stock", "Price", "Description", "Status", "Date Added", "Supplier ID"];
        const rows = filteredProducts.map(p => [
            p.id,
            `"${p.name.replace(/"/g, '""')}"`,
            p.category,
            p.stock,
            p.price,
            `"${p.description.replace(/"/g, '""')}"`,
            p.status,
            p.createdAt,
            p.supplierId || ''
        ].join(','));

        const csvContent = "data:text/csv;charset=utf-8," + [csvHeaders.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "products.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div>
            <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                 <div className="flex flex-col md:flex-row items-center gap-4 w-full md:w-auto">
                    <select
                      onChange={(e) => { setFilter(e.target.value as Category | 'all'); setCurrentPage(1); }}
                      value={filter}
                      className="w-full md:w-auto p-2 border rounded-md bg-gray-50 dark:bg-gray-700 dark:text-dark-text-primary dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="all">All Categories</option>
                      {Object.values(Category).map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                </div>
                <div className="flex items-center gap-2 w-full md:w-auto">
                     {canExport && (
                         <button
                            onClick={handleExport}
                            className="flex-1 md:flex-none flex items-center justify-center gap-2 w-full px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-md hover:bg-gray-700 dark:bg-gray-500 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-150"
                        >
                            <ExportIcon className="w-4 h-4" />
                            Export
                        </button>
                     )}
                    {canManage && (
                        <button
                            onClick={() => setIsAddModalOpen(true)}
                            className="flex-1 md:flex-none px-5 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition duration-150"
                        >
                            Add Product
                        </button>
                    )}
                </div>
            </div>
            
            <ProductTable
                products={paginatedProducts}
                suppliers={suppliers}
                onEdit={setEditingProduct}
                onDelete={handleDelete}
                onAdjustStock={setAdjustingStockProduct}
            />
            
            <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
            />

            {isAddModalOpen && (
                <AddProductModal
                    onClose={() => setIsAddModalOpen(false)}
                    onAddProduct={onAddProduct}
                    suppliers={suppliers}
                />
            )}

            {editingProduct && (
                <EditProductModal
                    product={editingProduct}
                    onClose={() => setEditingProduct(null)}
                    onUpdateProduct={handleUpdate}
                    suppliers={suppliers}
                />
            )}

            {adjustingStockProduct && (
                <StockAdjustmentModal
                    product={adjustingStockProduct}
                    onClose={() => setAdjustingStockProduct(null)}
                    onAdjust={handleStockAdjustment}
                />
            )}
        </div>
    );
};

export default ProductsPage;