import React from 'react';
import { Sale, Product, Customer, SaleStatus } from '../types';
import { CloseIcon, PrinterIcon } from './icons';

const statusColor = (status: SaleStatus) => {
    switch (status) {
      case SaleStatus.Paid:
        return 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300';
      case SaleStatus.Pending:
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300';
      case SaleStatus.Overdue:
        return 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
};

interface ViewInvoiceModalProps {
  invoice: Sale;
  products: Product[];
  customers: Customer[];
  onClose: () => void;
}

const ViewInvoiceModal: React.FC<ViewInvoiceModalProps> = ({ invoice, products, customers, onClose }) => {
  const customer = customers.find(c => c.name === invoice.customerName);

  const handlePrint = () => {
    const content = document.getElementById("invoice-content-for-print");
    if (content) {
      const printWindow = window.open("", "_blank");
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Invoice #${invoice.id}</title>
              <script src="https://cdn.tailwindcss.com"><\/script>
              <script>
                tailwind.config = {
                  darkMode: 'class',
                  theme: {
                    extend: {
                      colors: {
                        'primary': {'500': '#10b981', '600': '#059669'},
                        'text-primary': '#1f2937',
                        'text-secondary': '#6b7280',
                        'gray-50': '#f9fafb',
                      }
                    }
                  }
                }
              <\/script>
            </head>
            <body class="p-8 font-sans">
              ${content.innerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        setTimeout(() => {
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }, 250);
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center p-4">
      <div className="bg-white dark:bg-dark-card-bg rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col">
          <div className="flex justify-between items-center p-5 border-b dark:border-gray-700">
              <h3 className="text-xl font-semibold text-text-primary dark:text-dark-text-primary">Invoice Details</h3>
              <div className="flex items-center gap-2">
                  <button onClick={handlePrint} className="flex items-center gap-2 px-3 py-2 text-sm bg-gray-200 text-text-secondary rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:text-dark-text-secondary dark:hover:bg-gray-500">
                      <PrinterIcon className="w-4 h-4" />
                      Print
                  </button>
                  <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                      <CloseIcon className="w-6 h-6" />
                  </button>
              </div>
          </div>
          
          <div id="invoice-content-for-print" className="p-8 overflow-y-auto">
              <div className="flex justify-between items-start mb-8">
                  <div>
                      <h1 className="text-3xl font-bold text-text-primary">Invoice</h1>
                      <p className="text-text-secondary">Invoice ID: {invoice.id}</p>
                  </div>
                  <div className="text-right">
                      <h2 className="text-xl font-bold text-text-primary">SmartERP Inc.</h2>
                      <p className="text-text-secondary">123 Business Rd, Suite 100<br/>Commerce City, 12345</p>
                  </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                  <div>
                      <h3 className="text-sm font-semibold text-text-secondary mb-1">BILL TO</h3>
                      <p className="font-medium text-text-primary">{customer?.name || invoice.customerName}</p>
                      <p className="text-text-secondary">{customer?.email}</p>
                      <p className="text-text-secondary">{customer?.phone}</p>
                  </div>
                  <div className="text-right">
                      <div className="mb-2">
                          <p className="text-sm font-semibold text-text-secondary">Invoice Date</p>
                          <p className="font-medium text-text-primary">{invoice.date}</p>
                      </div>
                      <div>
                          <p className="text-sm font-semibold text-text-secondary">Status</p>
                          <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColor(invoice.status).replace('dark:bg-green-900/50', 'bg-green-100').replace('dark:bg-yellow-900/50', 'bg-yellow-100').replace('dark:bg-red-900/50', 'bg-red-100')}`}>{invoice.status}</span>
                      </div>
                  </div>
              </div>

              <table className="w-full text-left table-auto mb-8">
                  <thead className="bg-gray-50">
                      <tr>
                          <th className="p-3 text-xs font-semibold text-text-secondary uppercase">Product</th>
                          <th className="p-3 text-xs font-semibold text-text-secondary uppercase text-center">Qty</th>
                          <th className="p-3 text-xs font-semibold text-text-secondary uppercase text-right">Unit Price</th>
                          <th className="p-3 text-xs font-semibold text-text-secondary uppercase text-right">Total</th>
                      </tr>
                  </thead>
                  <tbody>
                      {invoice.products.map((item, index) => {
                          const product = products.find(p => p.id === item.productId);
                          const total = item.quantity * item.unitPrice;
                          return (
                              <tr key={index} className="border-b">
                                  <td className="p-3 font-medium text-text-primary">{product?.name || 'Unknown Product'}</td>
                                  <td className="p-3 text-text-secondary text-center">{item.quantity}</td>
                                  <td className="p-3 text-text-secondary text-right">${item.unitPrice.toFixed(2)}</td>
                                  <td className="p-3 text-text-secondary text-right">${total.toFixed(2)}</td>
                              </tr>
                          );
                      })}
                  </tbody>
              </table>

              <div className="flex justify-end">
                  <div className="w-full max-w-xs">
                      <div className="flex justify-between text-text-primary font-semibold text-lg">
                          <span>Grand Total</span>
                          <span>${invoice.amount.toFixed(2)}</span>
                      </div>
                  </div>
              </div>

              <div className="text-center text-xs text-text-secondary mt-12">
                <p>Thank you for your business!</p>
                <p>SmartERP Inc. | (123) 456-7890 | contact@smarterp.com</p>
              </div>
          </div>
      </div>
    </div>
  );
};

export default ViewInvoiceModal;