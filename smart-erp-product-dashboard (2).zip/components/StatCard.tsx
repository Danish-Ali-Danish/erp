import React from 'react';

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ElementType;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon }) => {
  return (
    <div className="bg-card-bg dark:bg-dark-card-bg p-6 rounded-lg shadow-md flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-text-secondary dark:text-dark-text-secondary">{title}</p>
        <p className="text-2xl font-bold text-text-primary dark:text-dark-text-primary">{value}</p>
      </div>
      <div className="bg-primary-100 dark:bg-primary-900/50 rounded-full p-3">
        <Icon className="h-6 w-6 text-primary-600 dark:text-primary-400" />
      </div>
    </div>
  );
};

export default StatCard;