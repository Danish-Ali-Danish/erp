
import React, { useState, useMemo } from 'react';
import { Sale, SaleStatus, Product, Customer } from '../types';
import { ChevronUpIcon, ChevronDownIcon, ExportIcon } from './icons';
import ViewInvoiceModal from './ViewInvoiceModal';
import CreateInvoiceModal from './CreateInvoiceModal';
import Pagination from './Pagination';
import { useAuth } from '../auth/AuthContext';

type SortKey = keyof Sale;

const statusColor = (status: SaleStatus) => {
    switch (status) {
      case SaleStatus.Paid:
        return 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300';
      case SaleStatus.Pending:
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300';
      case SaleStatus.Overdue:
        return 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
};

const SalesTable: React.FC<{sales: Sale[], onViewInvoice: (sale: Sale) => void}> = ({sales, onViewInvoice}) => {
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'ascending' | 'descending' } | null>({ key: 'date', direction: 'descending' });
    
    const sortedSales = useMemo(() => {
        let sortableItems = [...sales];
        if (sortConfig !== null) {
            sortableItems.sort((a, b) => {
                const aValue = a[sortConfig.key];
                const bValue = b[sortConfig.key];
                if (aValue < bValue) {
                    return sortConfig.direction === 'ascending' ? -1 : 1;
                }
                if (aValue > bValue) {
                    return sortConfig.direction === 'ascending' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableItems;
    }, [sales, sortConfig]);

    const requestSort = (key: SortKey) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (key: SortKey) => {
        if (!sortConfig || sortConfig.key !== key) {
            return <ChevronUpIcon className="w-4 h-4 text-gray-400 invisible group-hover:visible" />;
        }
        return sortConfig.direction === 'ascending' ? <ChevronUpIcon className="w-4 h-4" /> : <ChevronDownIcon className="w-4 h-4" />;
    };

    const headers: { key: SortKey, label: string }[] = [
        { key: 'id', label: 'Invoice ID' },
        { key: 'customerName', label: 'Customer' },
        { key: 'date', label: 'Date' },
        { key: 'amount', label: 'Amount' },
    ];

    return (
        <div className="bg-card-bg dark:bg-dark-card-bg shadow-md rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-800">
                    <tr>
                        {headers.map((header) => (
                            <th key={header.key} scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">
                                <button onClick={() => requestSort(header.key)} className="group flex items-center space-x-1">
                                    <span>{header.label}</span>
                                    {getSortIcon(header.key)}
                                </button>
                            </th>
                        ))}
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Status</th>
                         <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200 dark:bg-dark-card-bg dark:divide-gray-700">
                    {sortedSales.map((sale) => (
                    <tr key={sale.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-text-primary dark:text-dark-text-primary">{sale.id}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{sale.customerName}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{sale.date}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">${sale.amount.toFixed(2)}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColor(sale.status)}`}>
                                {sale.status}
                            </span>
                        </td>
                         <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button onClick={() => onViewInvoice(sale)} className="text-primary-600 hover:text-primary-900 dark:text-primary-400 dark:hover:text-primary-200 transition duration-150 ease-in-out">
                                View Invoice
                            </button>
                        </td>
                    </tr>
                    ))}
                </tbody>
            </table>
            </div>
             {sales.length === 0 && (
                <div className="text-center py-10 text-text-secondary dark:text-dark-text-secondary">
                    No sales found.
                </div>
            )}
        </div>
    );
};

interface SalesPageProps {
    sales: Sale[];
    products: Product[];
    customers: Customer[];
    onAddSale: (newSale: Omit<Sale, 'id' | 'date'>) => void;
    searchTerm: string;
}

const ITEMS_PER_PAGE = 10;

const SalesPage: React.FC<SalesPageProps> = ({ sales, products, customers, onAddSale, searchTerm }) => {
    const { hasPermission } = useAuth();
    const canManage = hasPermission('manage_sales');
    const canExport = hasPermission('export_data');

    const [viewingInvoice, setViewingInvoice] = useState<Sale | null>(null);
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    
    const filteredSales = useMemo(() => {
        return sales.filter(s =>
            s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
            s.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            s.status.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [sales, searchTerm]);

    const totalPages = Math.ceil(filteredSales.length / ITEMS_PER_PAGE);
    const paginatedSales = filteredSales.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            setCurrentPage(page);
        }
    };

    const handleCreateInvoice = (newSale: Omit<Sale, 'id' | 'date'>) => {
        onAddSale(newSale);
        setIsCreateModalOpen(false);
    };

    const handleExport = () => {
        const csvHeaders = ["Invoice ID", "Customer Name", "Date", "Amount", "Status", "Products"];
        const rows = filteredSales.map(s => {
            const productDetails = s.products.map(p => `${p.quantity}x ${products.find(prod => prod.id === p.productId)?.name || 'Unknown'}`).join('; ');
            return [
                s.id,
                `"${s.customerName.replace(/"/g, '""')}"`,
                s.date,
                s.amount,
                s.status,
                `"${productDetails}"`
            ].join(',');
        });
        
        const csvContent = "data:text/csv;charset=utf-8," + [csvHeaders.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "sales.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div>
            <div className="flex justify-end items-center mb-6">
                 <div className="flex items-center gap-2">
                    {canExport && (
                        <button
                            onClick={handleExport}
                            className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-md hover:bg-gray-700 dark:bg-gray-500 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-150"
                        >
                            <ExportIcon className="w-4 h-4" />
                            Export
                        </button>
                    )}
                    {canManage && (
                        <button
                            onClick={() => setIsCreateModalOpen(true)}
                            className="px-5 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition duration-150"
                        >
                            Create Invoice
                        </button>
                    )}
                 </div>
            </div>
            <SalesTable sales={paginatedSales} onViewInvoice={setViewingInvoice} />
            <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
            />

            {viewingInvoice && (
                <ViewInvoiceModal
                    invoice={viewingInvoice}
                    products={products}
                    customers={customers}
                    onClose={() => setViewingInvoice(null)}
                />
            )}

            {isCreateModalOpen && (
                <CreateInvoiceModal
                    products={products}
                    customers={customers}
                    onClose={() => setIsCreateModalOpen(false)}
                    onAddSale={handleCreateInvoice}
                />
            )}
        </div>
    );
};

export default SalesPage;