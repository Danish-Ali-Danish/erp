import React, { useState } from 'react';
// FIX: Import the `Role` enum to use for typing and values.
import { Employee, EmployeeStatus, Role } from '../types';
import { CloseIcon } from './icons';

interface AddEmployeeModalProps {
  onClose: () => void;
  onAddEmployee: (employee: Omit<Employee, 'id' | 'startDate'>) => void;
}

const AddEmployeeModal: React.FC<AddEmployeeModalProps> = ({ onClose, onAddEmployee }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    // FIX: Initialize `role` with a valid `Role` enum value. This ensures `formData` has the correct type.
    role: Role.Staff,
    department: '',
    status: EmployeeStatus.Active
  });
  const [error, setError] = useState('');
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // FIX: The role is now a select with a default value, so the check for it being empty is no longer necessary.
    if (!formData.name.trim() || !formData.email.trim() || !formData.department.trim()) {
        setError('Please fill in all fields.');
        return;
    }
    onAddEmployee(formData);
    onClose();
  };

  const inputStyles = "mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center p-4">
      <div className="bg-white dark:bg-dark-card-bg rounded-lg shadow-xl w-full max-w-lg">
        <div className="flex justify-between items-center p-5 border-b dark:border-gray-700">
          <h3 className="text-xl font-semibold text-text-primary dark:text-dark-text-primary">Add New Employee</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
                <label htmlFor="name" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Full Name</label>
                <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className={inputStyles} required />
            </div>
            <div>
                <label htmlFor="email" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Email Address</label>
                <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} className={inputStyles} required />
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label htmlFor="role" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Role</label>
                    {/* FIX: Changed text input to a select dropdown to enforce valid `Role` enum values, matching the type definition. */}
                    <select id="role" name="role" value={formData.role} onChange={handleChange} className={inputStyles} required>
                        {Object.values(Role).map(roleValue => (
                            <option key={roleValue} value={roleValue}>{roleValue}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label htmlFor="department" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Department</label>
                    <input type="text" id="department" name="department" value={formData.department} onChange={handleChange} className={inputStyles} required />
                </div>
            </div>
            <div>
                <label htmlFor="status" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">Status</label>
                <select id="status" name="status" value={formData.status} onChange={handleChange} className={inputStyles}>
                    {Object.values(EmployeeStatus).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
            </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <div className="flex justify-end pt-4 space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-text-secondary rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:text-dark-text-secondary dark:hover:bg-gray-500">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700">Add Employee</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEmployeeModal;
