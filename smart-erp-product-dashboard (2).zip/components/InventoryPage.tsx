import React, { useState, useMemo } from 'react';
import { InventoryMovement, InventoryMovementType } from '../types';
import Pagination from './Pagination';

interface InventoryPageProps {
    inventoryMovements: InventoryMovement[];
    searchTerm: string;
}

const ITEMS_PER_PAGE = 15;

const movementTypeColor = (type: InventoryMovementType) => {
    return type === InventoryMovementType.In
        ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300'
        : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300';
};

const formatTimestamp = (isoString: string) => {
    const date = new Date(isoString);
    return `${date.toLocaleDateString()} at ${date.toLocaleTimeString()}`;
};

const InventoryPage: React.FC<InventoryPageProps> = ({ inventoryMovements, searchTerm }) => {
    const [currentPage, setCurrentPage] = useState(1);

    const filteredMovements = useMemo(() => {
        return inventoryMovements.filter(m =>
            m.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            m.productId.toLowerCase().includes(searchTerm.toLowerCase()) ||
            m.reason.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [inventoryMovements, searchTerm]);

    const totalPages = Math.ceil(filteredMovements.length / ITEMS_PER_PAGE);
    const paginatedMovements = filteredMovements.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            setCurrentPage(page);
        }
    };

    return (
        <div>
            <h2 className="text-2xl font-semibold text-text-primary dark:text-dark-text-primary mb-6 sr-only">Inventory Log</h2>
            <div className="bg-card-bg dark:bg-dark-card-bg shadow-md rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead className="bg-gray-50 dark:bg-gray-800">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Product</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Date</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Type</th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Quantity Change</th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">New Quantity</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Reason</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200 dark:bg-dark-card-bg dark:divide-gray-700">
                            {paginatedMovements.map(m => (
                                <tr key={m.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="text-sm font-medium text-text-primary dark:text-dark-text-primary">{m.productName}</div>
                                        <div className="text-sm text-text-secondary dark:text-dark-text-secondary">{m.productId}</div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{formatTimestamp(m.timestamp)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${movementTypeColor(m.type)}`}>
                                            {m.type}
                                        </span>
                                    </td>
                                    <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium text-right ${m.quantityChange > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                                        {m.quantityChange > 0 ? `+${m.quantityChange}` : m.quantityChange}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary text-right">{m.newQuantity}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary dark:text-dark-text-secondary">{m.reason}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 {filteredMovements.length === 0 && (
                    <div className="text-center py-10 text-text-secondary dark:text-dark-text-secondary">
                        No inventory movements found.
                    </div>
                )}
            </div>
            <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
            />
        </div>
    );
};

export default InventoryPage;