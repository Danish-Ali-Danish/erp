
import React from 'react';
import { Page } from '../App';
import { useAuth } from '../auth/AuthContext';
import { Permission } from '../types';
import { DashboardIcon, ProductsIcon, CustomersIcon, SalesIcon, SettingsIcon, UsersIcon, ChartBarIcon, ActivityIcon, ClipboardListIcon, TruckIcon, DocumentTextIcon } from './icons';

interface SidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  activePage: Page;
  setActivePage: (page: Page) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ sidebarOpen, setSidebarOpen, activePage, setActivePage }) => {
  const { currentUser, hasPermission } = useAuth();
  
  const navItems: { name: Page; icon: React.FC<{className?: string}>; permission: Permission }[] = [
    { name: 'Dashboard', icon: DashboardIcon, permission: 'view_dashboard' },
    { name: 'Products', icon: ProductsIcon, permission: 'view_products' },
    { name: 'Inventory', icon: ClipboardListIcon, permission: 'view_inventory' },
    { name: 'Suppliers', icon: TruckIcon, permission: 'view_suppliers' },
    { name: 'Customers', icon: CustomersIcon, permission: 'view_customers' },
    { name: 'Sales', icon: SalesIcon, permission: 'view_sales' },
    { name: 'PurchaseOrders', icon: DocumentTextIcon, permission: 'view_purchaseorders' },
    { name: 'HR', icon: UsersIcon, permission: 'view_hr' },
    { name: 'Reports', icon: ChartBarIcon, permission: 'view_reports' },
    { name: 'Activity', icon: ActivityIcon, permission: 'view_activity' },
    { name: 'Settings', icon: SettingsIcon, permission: 'view_settings' },
  ];
  
  const visibleNavItems = navItems.filter(item => hasPermission(item.permission));

  const handleNavClick = (page: Page) => {
    setActivePage(page);
    if (window.innerWidth < 1024) { // Close sidebar on mobile after click
        setSidebarOpen(false);
    }
  };
  
  const getPageDisplayName = (page: Page) => {
    if (page === 'PurchaseOrders') return 'Purchase Orders';
    return page;
  }

  if (!currentUser) return null;

  return (
    <>
      <div className={`fixed inset-0 bg-gray-900 bg-opacity-50 z-20 transition-opacity lg:hidden ${sidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
           onClick={() => setSidebarOpen(false)}>
      </div>
      <div className={`fixed inset-y-0 left-0 bg-sidebar-bg dark:bg-dark-sidebar-bg text-sidebar-text dark:text-dark-sidebar-text w-64 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:relative lg:translate-x-0 transition-transform duration-200 ease-in-out z-30 flex flex-col`}>
        <div className="flex items-center justify-center h-20 border-b border-gray-700 dark:border-gray-800">
          <h1 className="text-2xl font-bold text-white">SmartERP</h1>
        </div>
        <nav className="flex-1 mt-6">
          {visibleNavItems.map((item) => (
            <button 
                key={item.name} 
                onClick={() => handleNavClick(item.name)} 
                className={`flex items-center w-full px-6 py-3 transition-colors duration-200 text-left ${activePage === item.name ? 'bg-gray-700 dark:bg-gray-900/50 text-sidebar-active' : 'hover:bg-gray-700 hover:text-white dark:hover:bg-gray-900/50'}`}
            >
              <item.icon className="w-6 h-6" />
              <span className="mx-4 font-medium">{getPageDisplayName(item.name)}</span>
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-gray-700 dark:border-gray-800">
          <div className="flex items-center">
            <img className="h-10 w-10 rounded-full object-cover" src={`https://i.pravatar.cc/150?u=${currentUser.id}`} alt="user avatar"/>
            <div className="ml-3">
              <p className="text-sm font-semibold text-white">{currentUser.name}</p>
              <p className="text-xs text-sidebar-text dark:text-dark-sidebar-text">{currentUser.role}</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;