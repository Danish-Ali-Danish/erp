import React from 'react';
import { Sale, Product, Customer, SaleStatus, StockStatus } from '../types';

const ReportCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-card-bg dark:bg-dark-card-bg p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold text-text-primary dark:text-dark-text-primary border-b dark:border-gray-700 pb-3 mb-4">{title}</h3>
        <div>{children}</div>
    </div>
);

const Metric: React.FC<{ label: string; value: string | number }> = ({ label, value }) => (
    <div className="flex justify-between items-center py-2">
        <p className="text-sm text-text-secondary dark:text-dark-text-secondary">{label}</p>
        <p className="text-sm font-medium text-text-primary dark:text-dark-text-primary">{value}</p>
    </div>
);

interface ReportsPageProps {
    sales: Sale[];
    products: Product[];
    customers: Customer[];
}

const ReportsPage: React.FC<ReportsPageProps> = ({ sales, products, customers }) => {
    // Sales calculations
    const totalSales = sales.reduce((acc, sale) => acc + sale.amount, 0);
    const paidSales = sales.filter(s => s.status === SaleStatus.Paid).reduce((acc, sale) => acc + sale.amount, 0);
    const pendingSales = sales.filter(s => s.status === SaleStatus.Pending).reduce((acc, sale) => acc + sale.amount, 0);
    const averageSale = sales.length > 0 ? totalSales / sales.length : 0;

    // Inventory calculations
    const totalStockValue = products.reduce((acc, p) => acc + (p.stock * p.price), 0);
    const lowStockItems = products.filter(p => p.status === StockStatus.LowStock).length;
    const outOfStockItems = products.filter(p => p.status === StockStatus.OutOfStock).length;

    // Customer calculations
    const topCustomers = [...customers].sort((a, b) => b.totalSpent - a.totalSpent).slice(0, 3);
    
    return (
        <div>
            <h2 className="text-2xl font-semibold text-text-primary dark:text-dark-text-primary mb-6">Business Reports</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <ReportCard title="Sales Summary">
                    <Metric label="Total Revenue" value={`$${paidSales.toLocaleString('en-US', {minimumFractionDigits: 2})}`} />
                    <Metric label="Pending Revenue" value={`$${pendingSales.toLocaleString('en-US', {minimumFractionDigits: 2})}`} />
                    <Metric label="Average Sale Value" value={`$${averageSale.toLocaleString('en-US', {minimumFractionDigits: 2})}`} />
                    <Metric label="Total Transactions" value={sales.length} />
                </ReportCard>

                <ReportCard title="Inventory Status">
                    <Metric label="Total Inventory Value" value={`$${totalStockValue.toLocaleString('en-US', {minimumFractionDigits: 2})}`} />
                    <Metric label="Total Product SKUs" value={products.length} />
                    <Metric label="Low Stock Items" value={lowStockItems} />
                    <Metric label="Out of Stock Items" value={outOfStockItems} />
                </ReportCard>

                 <ReportCard title="Top Customers">
                    {topCustomers.map(customer => (
                         <Metric 
                            key={customer.id} 
                            label={customer.name} 
                            value={`$${customer.totalSpent.toLocaleString('en-US', {minimumFractionDigits: 2})}`} 
                        />
                    ))}
                </ReportCard>
            </div>
        </div>
    );
};

export default ReportsPage;
