import React, { useState } from 'react';
import ToggleSwitch from './ToggleSwitch';

interface SettingsPageProps {
  onResetData: () => void;
}

const SettingsCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-card-bg dark:bg-dark-card-bg p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold text-text-primary dark:text-dark-text-primary border-b dark:border-gray-700 pb-3 mb-4">{title}</h3>
        <div>{children}</div>
    </div>
);

const SettingsPage: React.FC<SettingsPageProps> = ({ onResetData }) => {
    const [notifications, setNotifications] = useState({
        lowStock: true,
        newSales: true,
        overdueInvoices: false,
        systemUpdates: true,
    });
    
    const handleToggle = (key: keyof typeof notifications) => {
        setNotifications(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const inputStyles = "mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
    const labelStyles = "block text-sm font-medium text-text-secondary dark:text-dark-text-secondary";

    const handleFormSubmit = (e: React.FormEvent, formName: string) => {
        e.preventDefault();
        alert(`${formName} settings saved! (This is a demo and data is not persisted).`);
    };

    return (
        <div>
            <h2 className="text-2xl font-semibold text-text-primary dark:text-dark-text-primary mb-6">System Settings</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-8">
                    <SettingsCard title="Profile Information">
                        <form onSubmit={(e) => handleFormSubmit(e, 'Profile')} className="space-y-4">
                            <div>
                                <label htmlFor="name" className={labelStyles}>Full Name</label>
                                <input type="text" id="name" defaultValue="Admin User" className={inputStyles} />
                            </div>
                            <div>
                                <label htmlFor="email" className={labelStyles}>Email Address</label>
                                <input type="email" id="email" defaultValue="admin@smarterp.com" className={inputStyles} />
                            </div>
                            <div className="flex justify-end">
                                <button type="submit" className="px-4 py-2 bg-primary-600 text-white text-sm font-medium rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 dark:focus:ring-offset-dark-card-bg">Save Profile</button>
                            </div>
                        </form>
                    </SettingsCard>
                     <SettingsCard title="Security">
                        <form onSubmit={(e) => handleFormSubmit(e, 'Password')} className="space-y-4">
                            <div>
                                <label htmlFor="current_password" className={labelStyles}>Current Password</label>
                                <input type="password" id="current_password" className={inputStyles} />
                            </div>
                            <div>
                                <label htmlFor="new_password" className={labelStyles}>New Password</label>
                                <input type="password" id="new_password" className={inputStyles} />
                            </div>
                             <div>
                                <label htmlFor="confirm_password" className={labelStyles}>Confirm New Password</label>
                                <input type="password" id="confirm_password" className={inputStyles} />
                            </div>
                            <div className="flex justify-end">
                                <button type="submit" className="px-4 py-2 bg-primary-600 text-white text-sm font-medium rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 dark:focus:ring-offset-dark-card-bg">Change Password</button>
                            </div>
                        </form>
                    </SettingsCard>
                </div>
                 <div className="space-y-8">
                    <SettingsCard title="Notification Preferences">
                        <div className="space-y-4">
                            <ToggleSwitch label="Low Stock Alerts" enabled={notifications.lowStock} onChange={() => handleToggle('lowStock')} />
                            <ToggleSwitch label="New Sale Notifications" enabled={notifications.newSales} onChange={() => handleToggle('newSales')} />
                            <ToggleSwitch label="Overdue Invoice Reminders" enabled={notifications.overdueInvoices} onChange={() => handleToggle('overdueInvoices')} />
                            <ToggleSwitch label="System & Maintenance Updates" enabled={notifications.systemUpdates} onChange={() => handleToggle('systemUpdates')} />
                        </div>
                    </SettingsCard>
                     <SettingsCard title="Data Management">
                        <div className="space-y-4">
                            <p className={labelStyles}>
                                Reset all application data to its initial state. This includes products, customers, sales, and employees.
                            </p>
                            <p className="text-sm text-red-600 dark:text-red-400">
                                <strong>Warning:</strong> This action is irreversible.
                            </p>
                             <div className="flex justify-start">
                                <button onClick={onResetData} className="px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 dark:focus:ring-offset-dark-card-bg">
                                    Reset Application Data
                                </button>
                            </div>
                        </div>
                     </SettingsCard>
                </div>
            </div>
        </div>
    );
};

export default SettingsPage;
