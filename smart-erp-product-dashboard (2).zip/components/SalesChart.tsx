import React from 'react';

interface SalesData {
    name: string;
    sales: number;
}

interface SalesChartProps {
    data: SalesData[];
}

const SalesChart: React.FC<SalesChartProps> = ({ data }) => {
    const chartHeight = 300;
    const chartWidth = 600;
    const barPadding = 10;
    const maxValue = Math.max(...data.map(d => d.sales)) * 1.1; // Add 10% padding to max value
    const barWidth = (chartWidth / data.length) - barPadding;

    return (
        <div className="bg-card-bg dark:bg-dark-card-bg p-6 rounded-lg shadow-md h-full">
            <h3 className="text-lg font-semibold text-text-primary dark:text-dark-text-primary mb-4">Monthly Sales Performance</h3>
            <div className="overflow-x-auto">
                <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} width="100%" height={chartHeight} aria-label="Sales chart" role="img">
                    <title>A bar chart showing sales data per month.</title>
                    {data.map((d, i) => {
                        const barHeight = (d.sales / maxValue) * (chartHeight - 40); // 40px for labels
                        const x = i * (barWidth + barPadding);
                        const y = chartHeight - barHeight - 20; // 20px for bottom labels
                        return (
                            <g key={d.name} className="group">
                                <rect
                                    x={x}
                                    y={y}
                                    width={barWidth}
                                    height={barHeight}
                                    className="fill-current text-primary-400 dark:text-primary-600 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors"
                                    rx="4"
                                >
                                  <title>{`${d.name}: $${d.sales.toLocaleString()}`}</title>
                                </rect>
                                <text x={x + barWidth / 2} y={chartHeight - 5} textAnchor="middle" className="text-xs fill-current text-text-secondary dark:text-dark-text-secondary">
                                    {d.name}
                                </text>
                                <text x={x + barWidth / 2} y={y - 5} textAnchor="middle" className="text-xs font-semibold fill-current text-text-primary dark:text-dark-text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                                    {`$${(d.sales/1000).toFixed(0)}k`}
                                </text>
                            </g>
                        );
                    })}
                    <line x1="0" y1={chartHeight - 20} x2={chartWidth} y2={chartHeight - 20} stroke="currentColor" className="text-gray-200 dark:text-gray-700" strokeWidth="1" />
                </svg>
            </div>
        </div>
    );
};

export default SalesChart;