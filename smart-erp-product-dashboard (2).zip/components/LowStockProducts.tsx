import React from 'react';
import { Product, StockStatus } from '../types';

interface LowStockProductsProps {
    products: Product[];
}

const LowStockProducts: React.FC<LowStockProductsProps> = ({ products }) => {
    
    const statusColor = (status: StockStatus) => {
        switch (status) {
          case StockStatus.LowStock:
            return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300';
          case StockStatus.OutOfStock:
            return 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300';
          default:
            return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
        }
    };

    return (
        <div className="bg-card-bg dark:bg-dark-card-bg shadow-md rounded-lg overflow-hidden h-full">
            <h3 className="text-lg font-semibold text-text-primary dark:text-dark-text-primary p-4 border-b dark:border-gray-700">Low Stock Products</h3>
            <div className="overflow-x-auto">
                {products.length > 0 ? (
                    <table className="min-w-full">
                        <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                            {products.map(product => (
                                <tr key={product.id}>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="text-sm font-medium text-text-primary dark:text-dark-text-primary">{product.name}</div>
                                        <div className="text-sm text-text-secondary dark:text-dark-text-secondary">Stock: {product.stock}</div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColor(product.status)}`}>
                                            {product.status}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <p className="p-6 text-sm text-text-secondary dark:text-dark-text-secondary">All products are well-stocked.</p>
                )}
            </div>
        </div>
    );
};

export default LowStockProducts;