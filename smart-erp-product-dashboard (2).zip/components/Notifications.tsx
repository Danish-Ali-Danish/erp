import React, { useState, useRef, useEffect } from 'react';
import { initialNotifications } from '../types';
import { BellIcon, BoxIcon, DollarIcon } from './icons';
import { NotificationType } from '../types';

const Notifications: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    const unreadCount = initialNotifications.filter(n => !n.read).length;

    const getIcon = (type: NotificationType) => {
        switch(type) {
            case NotificationType.Stock:
                return <BoxIcon className="w-5 h-5 text-yellow-500" />;
            case NotificationType.Sale:
                return <DollarIcon className="w-5 h-5 text-red-500" />;
            default:
                return <BellIcon className="w-5 h-5 text-blue-500" />;
        }
    }

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    return (
        <div className="relative" ref={containerRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="relative p-2 rounded-full text-gray-500 dark:text-dark-text-secondary hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-dark-header-bg"
            >
                <BellIcon className="h-6 w-6" />
                {unreadCount > 0 && (
                    <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                        {unreadCount}
                    </span>
                )}
            </button>

            {isOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-dark-card-bg rounded-lg shadow-xl overflow-hidden z-10 border dark:border-gray-700">
                    <div className="p-3 font-semibold text-text-primary dark:text-dark-text-primary border-b dark:border-gray-700">
                        Notifications
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                        {initialNotifications.map(notification => (
                             <div key={notification.id} className={`flex items-start gap-3 p-3 hover:bg-gray-100 dark:hover:bg-gray-700/50 ${!notification.read ? 'bg-primary-50 dark:bg-primary-900/20' : ''}`}>
                                <div className="flex-shrink-0 mt-1">
                                    {getIcon(notification.type)}
                                </div>
                                <div>
                                    <p className="text-sm text-text-primary dark:text-dark-text-primary">{notification.message}</p>
                                    <p className="text-xs text-text-secondary dark:text-dark-text-secondary">{notification.date}</p>
                                </div>
                                {!notification.read && (
                                    <div className="flex-shrink-0 ml-auto mt-1 h-2 w-2 bg-blue-500 rounded-full" aria-label="Unread"></div>
                                )}
                            </div>
                        ))}
                         {initialNotifications.length === 0 && (
                            <p className="text-center py-4 text-sm text-text-secondary dark:text-dark-text-secondary">No notifications</p>
                        )}
                    </div>
                     <div className="p-2 text-center border-t dark:border-gray-700">
                        <a href="#" className="text-sm text-primary-600 dark:text-primary-400 hover:underline">View all</a>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Notifications;
