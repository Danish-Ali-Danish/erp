import React from 'react';
import { Supplier } from '../types';

interface SuppliersPageProps {
    suppliers: Supplier[];
    searchTerm: string;
}

const SuppliersPage: React.FC<SuppliersPageProps> = ({ suppliers, searchTerm }) => {
    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                 <h2 className="text-2xl font-semibold text-text-primary dark:text-dark-text-primary sr-only">Suppliers</h2>
                 <button
                    className="px-5 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition duration-150"
                 >
                    Add Supplier
                </button>
            </div>
            <div className="bg-card-bg dark:bg-dark-card-bg shadow-md rounded-lg p-8 text-center">
                <h3 className="text-lg font-semibold text-text-primary dark:text-dark-text-primary">Supplier Management</h3>
                <p className="text-text-secondary dark:text-dark-text-secondary mt-2">
                    This module is under construction. Future updates will allow you to add, edit, and manage your suppliers here.
                </p>
            </div>
        </div>
    );
};

export default SuppliersPage;