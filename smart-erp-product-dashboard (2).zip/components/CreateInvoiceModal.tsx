import React, { useState, useMemo } from 'react';
import { Product, Customer, Sale, SaleStatus, SaleProductDetail } from '../types';
import { CloseIcon, TrashIcon } from './icons';

interface LineItem {
    id: number;
    productId: string;
    quantity: number;
}

interface CreateInvoiceModalProps {
    products: Product[];
    customers: Customer[];
    onClose: () => void;
    onAddSale: (sale: Omit<Sale, 'id' | 'date'>) => void;
}

const CreateInvoiceModal: React.FC<CreateInvoiceModalProps> = ({ products, customers, onClose, onAddSale }) => {
    const [customerId, setCustomerId] = useState<string>(customers.length > 0 ? customers[0].id : '');
    const [lineItems, setLineItems] = useState<LineItem[]>([{ id: Date.now(), productId: '', quantity: 1 }]);
    const [status, setStatus] = useState<SaleStatus>(SaleStatus.Pending);
    const [error, setError] = useState('');

    const availableProducts = useMemo(() => {
        const selectedProductIds = new Set(lineItems.map(item => item.productId));
        return products.filter(p => !selectedProductIds.has(p.id) && p.stock > 0);
    }, [products, lineItems]);

    const handleAddLineItem = () => {
        if (lineItems.length < products.length) {
            setLineItems([...lineItems, { id: Date.now(), productId: '', quantity: 1 }]);
        }
    };

    const handleRemoveLineItem = (id: number) => {
        setLineItems(lineItems.filter(item => item.id !== id));
    };

    const handleLineItemChange = (id: number, field: 'productId' | 'quantity', value: string | number) => {
        setLineItems(lineItems.map(item => {
            if (item.id === id) {
                if (field === 'productId') {
                    // Reset quantity to 1 when product changes
                    return { ...item, productId: value as string, quantity: 1 };
                }
                const product = products.find(p => p.id === item.productId);
                const quantity = Math.max(0, Math.min(Number(value), product?.stock || Number.MAX_SAFE_INTEGER));
                return { ...item, quantity: quantity };
            }
            return item;
        }));
    };

    const grandTotal = useMemo(() => {
        return lineItems.reduce((total, item) => {
            const product = products.find(p => p.id === item.productId);
            return total + (product ? product.price * item.quantity : 0);
        }, 0);
    }, [lineItems, products]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        const customer = customers.find(c => c.id === customerId);
        if (!customer) {
            setError('Please select a valid customer.');
            return;
        }

        const validLineItems = lineItems.filter(item => item.productId && item.quantity > 0);
        if (validLineItems.length === 0) {
            setError('Please add at least one product with a quantity greater than zero.');
            return;
        }

        const saleProducts: SaleProductDetail[] = validLineItems.map(item => {
            const product = products.find(p => p.id === item.productId)!;
            return {
                productId: item.productId,
                quantity: item.quantity,
                unitPrice: product.price
            };
        });

        const newSale: Omit<Sale, 'id' | 'date'> = {
            customerName: customer.name,
            status,
            products: saleProducts,
            amount: grandTotal
        };

        onAddSale(newSale);
    };
    
    const inputStyles = "block w-full border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white text-sm p-2";

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center p-4">
            <div className="bg-white dark:bg-dark-card-bg rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
                <div className="flex justify-between items-center p-5 border-b dark:border-gray-700">
                    <h3 className="text-xl font-semibold text-text-primary dark:text-dark-text-primary">Create New Invoice</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                <form id="invoice-form" onSubmit={handleSubmit} className="flex-grow overflow-y-auto p-6 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="customer" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary mb-1">Customer</label>
                            <select id="customer" value={customerId} onChange={e => setCustomerId(e.target.value)} className={inputStyles} required>
                                {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                        </div>
                         <div>
                            <label htmlFor="status" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary mb-1">Status</label>
                            <select id="status" value={status} onChange={e => setStatus(e.target.value as SaleStatus)} className={inputStyles}>
                                {Object.values(SaleStatus).map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                    </div>

                    <div className="border-t dark:border-gray-700 pt-4">
                        <h4 className="text-lg font-medium text-text-primary dark:text-dark-text-primary mb-2">Products</h4>
                        <div className="space-y-3">
                            {lineItems.map((item, index) => {
                                const currentProduct = products.find(p => p.id === item.productId);
                                return (
                                    <div key={item.id} className="grid grid-cols-12 gap-2 items-center">
                                        <div className="col-span-5">
                                            {index === 0 && <label className="text-xs text-text-secondary dark:text-dark-text-secondary">Product</label>}
                                            <select 
                                                value={item.productId}
                                                onChange={e => handleLineItemChange(item.id, 'productId', e.target.value)}
                                                className={inputStyles}
                                                required
                                            >
                                                <option value="" disabled>Select a product</option>
                                                {currentProduct && <option value={currentProduct.id}>{currentProduct.name}</option>}
                                                {availableProducts.map(p => <option key={p.id} value={p.id}>{p.name} ({p.stock} in stock)</option>)}
                                            </select>
                                        </div>
                                        <div className="col-span-2">
                                            {index === 0 && <label className="text-xs text-text-secondary dark:text-dark-text-secondary">Quantity</label>}
                                            <input 
                                                type="number" 
                                                value={item.quantity} 
                                                onChange={e => handleLineItemChange(item.id, 'quantity', e.target.value)}
                                                className={inputStyles}
                                                min="1"
                                                max={currentProduct?.stock}
                                                required
                                                disabled={!item.productId}
                                            />
                                        </div>
                                        <div className="col-span-2 text-right">
                                             {index === 0 && <label className="text-xs text-text-secondary dark:text-dark-text-secondary block">Unit Price</label>}
                                            <span className="text-sm text-text-secondary dark:text-dark-text-secondary pt-2 block">
                                                ${currentProduct?.price.toFixed(2) || '0.00'}
                                            </span>
                                        </div>
                                         <div className="col-span-2 text-right">
                                            {index === 0 && <label className="text-xs text-text-secondary dark:text-dark-text-secondary block">Total</label>}
                                            <span className="text-sm font-medium text-text-primary dark:text-dark-text-primary pt-2 block">
                                                ${((currentProduct?.price || 0) * item.quantity).toFixed(2)}
                                            </span>
                                        </div>
                                        <div className="col-span-1 flex justify-end">
                                            {index === 0 && <div className="h-[14px]"></div>}
                                            {lineItems.length > 1 && (
                                                <button type="button" onClick={() => handleRemoveLineItem(item.id)} className="text-red-500 hover:text-red-700 dark:hover:text-red-400 mt-5">
                                                    <TrashIcon className="w-5 h-5"/>
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                        <button type="button" onClick={handleAddLineItem} disabled={availableProducts.length === 0} className="mt-3 px-3 py-1 bg-primary-100 text-primary-700 text-sm font-medium rounded-md hover:bg-primary-200 dark:bg-primary-900/50 dark:text-primary-300 dark:hover:bg-primary-900 disabled:opacity-50 disabled:cursor-not-allowed">
                            + Add Item
                        </button>
                    </div>

                    <div className="flex justify-end pt-4 border-t dark:border-gray-700">
                        <div className="w-full max-w-xs space-y-2">
                            <div className="flex justify-between text-text-primary dark:text-dark-text-primary font-semibold text-lg">
                                <span>Grand Total</span>
                                <span>${grandTotal.toFixed(2)}</span>
                            </div>
                        </div>
                    </div>
                
                </form>
                <div className="p-6 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 rounded-b-lg">
                    {error && <p className="text-sm text-red-600 mb-2 text-right">{error}</p>}
                    <div className="flex justify-end space-x-2">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-text-secondary rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:text-dark-text-secondary dark:hover:bg-gray-500">Cancel</button>
                        <button type="submit" form="invoice-form" className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700">Create Invoice</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CreateInvoiceModal;