import React from 'react';
import { Product, StockStatus, SaleStatus, Sale, Customer } from '../types';
import StatCard from './StatCard';
import SalesChart from './SalesChart';
import LowStockProducts from './LowStockProducts';
import { ProductsIcon, DollarIcon, BoxIcon, CustomersIcon } from './icons';
import { salesDataForChart } from '../types';

interface DashboardProps {
    products: Product[];
    sales: Sale[];
    customers: Customer[];
}

const Dashboard: React.FC<DashboardProps> = ({ products, sales, customers }) => {
    const totalRevenue = sales.filter(s => s.status === SaleStatus.Paid).reduce((acc, s) => acc + s.amount, 0);
    const totalStock = products.reduce((acc, p) => acc + p.stock, 0);
    const totalProducts = products.length;
    const totalCustomers = customers.length;
    const lowStockProducts = products.filter(p => p.status === StockStatus.LowStock || p.status === StockStatus.OutOfStock);

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <StatCard title="Total Revenue" value={`$${totalRevenue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`} icon={DollarIcon} />
                <StatCard title="Total Products" value={totalProducts.toString()} icon={ProductsIcon} />
                <StatCard title="Total Stock Units" value={totalStock.toLocaleString()} icon={BoxIcon} />
                <StatCard title="Total Customers" value={totalCustomers.toLocaleString()} icon={CustomersIcon} />
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <SalesChart data={salesDataForChart} />
                </div>
                <div>
                    <LowStockProducts products={lowStockProducts} />
                </div>
            </div>
        </div>
    );
};

export default Dashboard;