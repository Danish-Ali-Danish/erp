

import { GoogleGenAI } from "@google/genai";

// Ensure the API key is available in the environment variables
if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateDescription = async (productName: string, keywords: string): Promise<string> => {
  const prompt = `
    You are a world-class e-commerce copywriter. Your goal is to generate a highly creative and compelling product description.
    
    Product Name: "${productName}"
    Optional Keywords: "${keywords || 'None provided'}"
    
    Instructions:
    1.  The description must be a single, engaging paragraph between 40 and 70 words.
    2.  Focus on the *benefits* for the user, not just the features.
    3.  Incorporate the product name and keywords naturally.
    4.  The tone should be professional yet persuasive.
    5.  Do not use placeholders.
    6.  Output only the description text, with no introductory phrases.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.8,
        topP: 1,
        topK: 32,
        maxOutputTokens: 150,
        thinkingConfig: { thinkingBudget: 0 } // Disable thinking for faster response
      }
    });
    
    const text = response.text;
    if (text) {
      return text.trim();
    } else {
      throw new Error("Received an empty response from the API.");
    }
  } catch (error) {
    console.error("Error generating description from Gemini API:", error);
    // Provide a fallback or re-throw the error
    throw new Error("Failed to generate product description.");
  }
};