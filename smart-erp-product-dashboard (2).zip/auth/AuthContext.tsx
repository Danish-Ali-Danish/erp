
import React, { createContext, useState, useContext, ReactNode, useCallback } from 'react';
import { Employee, Role, Permission, ROLES } from '../types';

interface AuthContextType {
  currentUser: Employee | null;
  login: (user: Employee) => void;
  logout: () => void;
  hasPermission: (permission: Permission) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<Employee | null>(() => {
    const storedUser = sessionStorage.getItem('currentUser');
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const login = (user: Employee) => {
    setCurrentUser(user);
    sessionStorage.setItem('currentUser', JSON.stringify(user));
  };

  const logout = () => {
    setCurrentUser(null);
    sessionStorage.removeItem('currentUser');
  };

  const hasPermission = useCallback((permission: Permission): boolean => {
    if (!currentUser) {
      return false;
    }
    const userRole: Role = currentUser.role;
    const permissionsForRole = ROLES[userRole];
    return permissionsForRole?.includes(permission) ?? false;
  }, [currentUser]);

  return (
    <AuthContext.Provider value={{ currentUser, login, logout, hasPermission }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
